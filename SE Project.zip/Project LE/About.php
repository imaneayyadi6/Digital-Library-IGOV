<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About</title>
    <link rel="chortcut icon" href="um5.png" type="images/png">    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Dela+Gothic+One&family=Poppins:wght@100;200;400;500&display=swap">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        html {
            font-size: 62.5%;
        }

        body {
            margin: 0;
            overflow-x: hidden;
            background: linear-gradient(45deg, #1e3c72, #2a5298);
            background-size: 400% 400%;
            animation: gradientMove 15s ease infinite;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            color: #ffffff; /* White text color for contrast */
        }

        @keyframes gradientMove {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }

        header {
            text-align: center;
            padding: 50px 0;
            animation: fadeIn 1.5s ease-out;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(-50px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        h1 {
            font-size: 36px;
            color: #93C5FD; /* Light blue */
            font-family: 'Dela Gothic One', sans-serif;
        }
        section {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 70vh;
        }

        article {
            background-color: rgba(30, 58, 138, 0.8); /* Semi-transparent blue for content box */
            padding: 20px;
            margin: 20px;
            border-radius: 10px;
            text-align: center;
            max-width: 800px;
            animation: fadeInUp 1.5s ease-out;
        }

        article h3 {
            font-family: 'Dela Gothic One', sans-serif;
            font-size: 24px;
            margin-bottom: 10px;
            color: #93C5FD; /* Light blue for headings */
        }

        article p {
            font-size: 20px;
            line-height: 1.6;
            margin-bottom: 20px;
            color: #E0F2FE; /* Light blue text for readability */
        }

        footer {
            text-align: center;
            padding: 20px 0;
            background-color: rgba(30, 58, 138, 0.8); /* Matching footer with content box */
            margin-bottom: 10px;
        }

        .foot {
            font-size: 10px;
            line-height: 1.5;
            margin-bottom: 10px;
            color: #E0F2FE; /* Light blue for footer text */
        }

        .footersection a {
            text-decoration: none;
            color: #93C5FD; /* Light blue for footer links */
            font-weight: bold;
            font-size: 20px;
        }

        .footersection {
            padding-bottom: 5px;
            padding-left: 50px;
            display: flex;
            justify-content: left;
            align-items: center;
            height: 8vh;
        }


        /* Floating bubbles animation */
        .floating {
            position: absolute;
            width: 80px;
            height: 80px;
            border-radius: 50%;
            background-color: rgba(93, 164, 226, 0.7); /* Soft blue bubble color */
            animation: floatAnimation 4s ease-in-out infinite;
        }

        @keyframes floatAnimation {
            0% {
                transform: translate(0, 0);
            }
            50% {
                transform: translate(150px, -200px);
            }
            100% {
                transform: translate(0, 0);
            }
        }

        .floating1 {
            top: 10%;
            left: 10%;
            animation-delay: 0s;
        }

        .floating2 {
            top: 50%;
            left: 60%;
            animation-delay: 1s;
        }

        .floating3 {
            top: 80%;
            left: 30%;
            animation-delay: 2s;
        }

        .floating4 {
            top: 15%;
            left: 80%;
            animation-delay: 3s;
        }

        /* Styling for clickable logo */
        .logo-link {
            text-decoration: none;
            color: inherit;
        }

        .logo {
            cursor: pointer;
            color: #ffffff;
            font-size: 3rem;
            font-weight: bold;
            letter-spacing: 2px;
            text-transform: uppercase;
            font-family: 'Dela Gothic One', sans-serif;
        }

    </style>
</head>
<body>
<header>
        <div>
        <div><a href="javascript:history.back()" class="logo-link"><h1 >About Our Library</h1></a></div>

</header>

<section>
    <article>
        <p>At the Faculty of Sciences in Rabat, we believe that access to information is the key to learning. Our library is designed to foster intellectual growth and innovation, aligning with our Master’s program in Computer Science, Governance, and Digital Transformation. As a vibrant center of knowledge, the library not only provides exceptional resources but also offers a space where students can immerse themselves in diverse ideas and digital technologies.

        With a rich collection of books ranging from timeless classics to cutting-edge contemporary works, our library reflects the diversity of fields explored in our institution. Whether you're reading a captivating novel, seeking in-depth academic resources, or collaborating on digital projects in our designated workspaces, you'll find a sanctuary for learning here.</p>
    </article>   
</section>

<hr>

<footer>
    <p class="foot">&copy; 2024 Digital Library IGOV. All rights reserved.</p>
</footer>

<!-- Floating interactive bubbles -->
<div class="floating floating1"></div>
<div class="floating floating2"></div>
<div class="floating floating3"></div>
<div class="floating floating4"></div>

</body>
</html>
