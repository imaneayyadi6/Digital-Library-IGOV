<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Handle the button click here
    echo 'Button clicked!';
    // You can add further logic or redirection as needed
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ESEFO-BiBlio</title>
    <link rel="shortcut icon" href="logo.png" type="image/png">

    <style>
        @import url('https://fonts.googleapis.com/css2?family=Dela+Gothic+One&family=Poppins:wght@100;200;400;500&display=swap');

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        html {
            font-size: 62.5%;
        }

        body {
            margin: 0;
            overflow-x: hidden;
            background-image: url(book.jpg); 
            color: #001F3F;
        }

        .container {
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: flex-start;
            text-align: left;
            padding-left: 10%;
            animation: fadeIn 1.5s ease-out;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(-50px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        section {
            position: absolute;
            top: 20px;
            right: 6%;
            z-index: 2;
        }

        .menu {
            background-color: #fff;
            height: 60px;
            width: 60px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .menu:hover {
            background-color: #ecf0f1;
        }

        .menu::before,
        .menu::after {
            position: absolute;
            content: "";
            height: 4px;
            width: 20px;
            background-color: #3498db;
            border-radius: 6px;
            transition: transform 0.3s ease;
        }

        .menu::after {
            transform: translateY(8px);
        }

        .menu.active::before {
            transform: translateY(-8px) rotate(-45deg);
        }

        .menu.active::after {
            transform: translateY(0) rotate(45deg);
        }

        .content {
            z-index: 1;
        }

        .logo {
            padding-top: 20px;
        }

        .logo h2 {
            font-family: 'Dela Gothic One', sans-serif;
            font-size: 30px;
            font-weight: 100;
            letter-spacing: 3px;
        }

        .content hr {
            border: 0;
            height: 6px;
            max-width: 280px;
            margin-top: 8px;
            background-color: #fff;
            border-radius: 6px;
        }

        .content h1 {
            font-size: 60px;
            font-weight: 400;
            line-height: 80px;
            animation: fadeInUp 1.5s ease-out;
        }

        .content p {
            max-width: 300px;
            margin: 20px auto;
            line-height: 20px;
            font-size: 15px;
            animation: fadeIn 1.5s ease-out;
        }

        .content .btn {
            text-decoration: none;
            border: 1px solid #001F3F;
            color: #001F3F;
            padding: 15px 34px;
            display: inline-block;
            margin-top: 20px;
            border-radius: 30px;
            transition: background-color 0.3s ease, color 0.3s ease;
        }

        .content .btn:hover {
            background-color: #001F3F;
            border: 1px solid #001F3F;
            color: #fff;
        }
        .lg {
            width: 160px;
            height: 160px;
            margin-right: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
       
        <div class="content">
            <img class="lg" src="umpo.png">
            <div class="logo"><h2>ESEF-O</h2></div>
            <hr>
            <h1>Bibliothèque Numérique</h1>
            <hr>
            <a href="index.php" class="btn">Connexion</a>
        </div>
    </div>

    <script>
        function toggleMenu() {
            document.querySelector('.menu').classList.toggle('active');
        }
    </script>
</body>
</html>
