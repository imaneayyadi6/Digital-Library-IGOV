<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Services</title>
    <link rel="chortcut icon" href="um5.png" type="images/png">    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Dela+Gothic+One&family=Poppins:wght@100;200;400;500&display=swap">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background-color: #1E3A8A; /* Deep blue background */
            color: #ffffff; /* White text */
            font-family: 'Poppins', sans-serif;
            overflow-x: hidden;
        }

        header {
            text-align: center;
            padding: 50px 0;
            animation: fadeIn 1.5s ease-out;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(-50px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        h1 {
            font-size: 36px;
            color: #93C5FD; /* Light blue */
            font-family: 'Dela Gothic One', sans-serif;
        }

        section {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-wrap: wrap;
            gap: 30px;
            padding: 50px;
        }

/* Service Card Styling */
.service-card {
    background-color:#93C5FD; /* Semi-transparent blue */
    border-radius: 15px;
    padding: 30px;
    width: 250px;
    text-align: center;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.3);
    transition: transform 0.3s ease, box-shadow 0.3s ease;
    height: 350px; /* Adjusted height to make cards taller */
    display: flex;
    flex-direction: column;
    justify-content: space-between; /* Ensures content is spaced properly */
}

/* Card Title (Heading) */
.service-card h3 {
    font-size: 24px;
    color: #1E3A8A; /* Light blue for the headings */
    margin-bottom: 15px;
    font-family: 'Dela Gothic One', sans-serif;
}

/* Card Description (Paragraph) */
.service-card p {
    font-size: 16px; /* Slightly reduced font size for better spacing */
    line-height: 1.4; /* Adjusted line height */
    color: #1E3A8A;
    margin-top: 10px; /* Added margin to the top to create some space between content */
    flex-grow: 1; /* Ensures text takes up remaining space if needed */
}

/* Hover Effect */
.service-card:hover {
    transform: translateY(-10px);
    box-shadow: 0 8px 25px rgba(0, 0, 0, 0.5);
}


        footer {
            background-color: rgba(30, 58, 138, 0.8); /* Matching the background color */
            color: #E0F2FE;
            padding: 20px;
            text-align: center;
            margin-top: 40px;
        }

        .footersection {
            padding-bottom: 5px;
            padding-left: 50px;
            display: flex;
            justify-content: left;
            align-items: center;
            height: 8vh;
        }

        .footersection a {
            text-decoration: none;
            color: #93C5FD;
            font-weight: bold;
            font-size: 18px;
            transition: color 0.3s ease;
        }

        .footersection a:hover {
            color: #ffffff;
        }

        /* Floating bubbles animation */
        .floating {
            position: absolute;
            width: 80px;
            height: 80px;
            border-radius: 50%;
            background-color: rgba(93, 164, 226, 0.7); /* Soft blue bubble color */
            animation: floatAnimation 4s ease-in-out infinite;
        }

        @keyframes floatAnimation {
            0% {
                transform: translate(0, 0);
            }
            50% {
                transform: translate(150px, -200px);
            }
            100% {
                transform: translate(0, 0);
            }
        }

        .floating1 {
            top: 10%;
            left: 10%;
            animation-delay: 0s;
        }

        .floating2 {
            top: 50%;
            left: 60%;
            animation-delay: 1s;
        }

        .floating3 {
            top: 80%;
            left: 30%;
            animation-delay: 2s;
        }

        .floating4 {
            top: 15%;
            left: 80%;
            animation-delay: 3s;
        }
        .logo-link {
            text-decoration: none;
            color: inherit;
        }
    </style>
</head>
<body>

<header>
    
        <div><a href="javascript:history.back()" class="logo-link"><h1 >Our Services</h1></a></div>
</header>

<section>
    <div class="service-card">
        <h3>Book Borrowing</h3>
        <p>Explore a wide range of books to enhance your knowledge in computer science, governance, and digital transformation, helping you stay updated with the latest trends in these fields.</p>
    </div>
    <div class="service-card">
        <h3>Study Spaces</h3>
        <p>Enjoy quiet reading rooms, individual study areas, and equipped spaces ideal for focused research or group projects in governance and digital transformation.</p>
    </div>
    <div class="service-card">
        <h3>Digital Resources</h3>
        <p>Access online databases, journals, and e-books to keep up with the latest research in digital transformation, governance, and computer science.</p>
    </div>
    <div class="service-card">
        <h3>Cultural and Academic Events</h3>
        <p>Join workshops, conferences, and seminars to engage with experts, discuss trends, and enrich your learning experience in governance and technology.</p>
    </div>
</section>

<footer>
    <p>&copy; 2024 Digital Library IGOV. All rights reserved.</p>
</footer>

<!-- Floating interactive bubbles -->
<div class="floating floating1"></div>
<div class="floating floating2"></div>
<div class="floating floating3"></div>
<div class="floating floating4"></div>

</body>
</html>
