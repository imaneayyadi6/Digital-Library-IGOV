
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thanks</title>
    <link rel="chortcut icon" href="um5.png" type="images/png">

    <style>
        body {
            font-family: 'Montserrat', sans-serif;
            background-color: #f6f5f7;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            height: 100vh;
            margin: -20px 0 50px;
        }

        h1 {
            font-weight: bold;
            color:#2a5298;
        }

        p {
            font-size: 14px;
            font-weight: 100;
            line-height: 20px;
            letter-spacing: 0.5px;
            color: #333;
            margin: 20px 0 30px;
        }

        .container {
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            max-width: 600px;
            margin: auto;
        }

        img {
            max-width: 100%;
            height: auto;
            margin-top: 20px;
        }

        .back-button {
            margin-top: 20px;
            background-color:#2a5298;
            color: #fff;
            border: none;
            padding: 10px 20px;
            font-size: 16px;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.3s;
        }


        /* Floating bubbles animation */
  .floating {
            position: absolute;
            width: 80px;
            height: 80px;
            border-radius: 50%;
            background-color: rgba(93, 164, 226, 0.7); /* Soft blue bubble color */
            animation: floatAnimation 4s ease-in-out infinite;
        }

        @keyframes floatAnimation {
            0% {
                transform: translate(0, 0);
            }
            50% {
                transform: translate(150px, -200px);
            }
            100% {
                transform: translate(0, 0);
            }
        }

        .floating1 {
            top: 10%;
            left: 10%;
            animation-delay: 0s;
        }

        .floating2 {
            top: 50%;
            left: 60%;
            animation-delay: 1s;
        }

        .floating3 {
            top: 80%;
            left: 30%;
            animation-delay: 2s;
        }

        .floating4 {
            top: 15%;
            left: 80%;
            animation-delay: 3s;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Thank you for your registration!</h1>
        <p>We are delighted to have you with us.</p>
        <button class="back-button" onclick="goBack()">Back</button>
    </div>

    <script>
        function goBack() {
            window.location.href = "Connexion.php";
        }
    </script>
</body>
<!-- Floating interactive bubbles -->
<div class="floating floating1"></div>
    <div class="floating floating2"></div>
    <div class="floating floating3"></div>
    <div class="floating floating4"></div>
</html>
