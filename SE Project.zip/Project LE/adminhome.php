<?php
include("setting.php");
session_start();
if(!isset($_SESSION['aid']))
{
	header("location:index.php");
}
$aid=$_SESSION['aid'];
$a=mysqli_query($set,"SELECT * FROM admin WHERE aid='$aid'");
$b=mysqli_fetch_array($a);
$name=$b['name'];
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Admin Connexion</title>
    <link rel="chortcut icon" href="um5.png" type="images/png">
    <style>@import url('https://fonts.googleapis.com/css?family=Montserrat:400,800');

* {
    box-sizing: border-box;
}

body {
    background: #e0f2fe;
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
    font-family: 'Montserrat', sans-serif;
    height: 100vh;
    margin: -20px 0 50px;
}


a {
    color: #333;
    font-size: 14px;
    text-decoration: none;
    margin: 15px 0;
}

button {
    border-radius: 20px;
    border: 1px solid #fff;
    background-color: #fff;
    color:  #fff;
    font-size: 12px;
    font-weight: bold;
    padding: 12px 45px;
    letter-spacing: 1px;
    text-transform: uppercase;
    transition: transform 80ms ease-in;
}

.container {
background-color: #352322;
border-radius: 10px;
box-shadow: 0 14px 28px rgba(0, 0, 0, 0.25), 0 10px 10px rgba(0, 0, 0, 0.22);
position: relative;
overflow: hidden;
width: 700px;
max-width: 80%;
min-height: 500px; 
margin: 8px 0; 
}


@keyframes show {
    0%, 49.99% {
        opacity: 0;
        z-index: 1;
    }
    
    50%, 100% {
        opacity: 1;
        z-index: 5;
    }
}

form {
    background: linear-gradient(45deg, #1e3c72, #2a5298);
    background-size: 100% 100%;
    animation: gradientAnimation 8s ease infinite;
    display: flex;
    align-items: left;
    justify-content: center;
    flex-direction: column;
    padding: 0 50px;
    height: 100%;
    text-align: left;
}

@keyframes gradientAnimation {
    0% {
        background-position: 0% 50%;
    }
    50% {
        background-position: 100% 50%;
    }
    100% {
        background-position: 0% 50%;
    }
}
.labels ,td{
            font-family: 'Segoe UI', sans-serif;
            color: #f6f5f7;
           font-size: 18px;margin-top: 20px;  
        }
u ,a  {
    color:#fff;
}
.a{
    color:#4c372f;
}
.floating {
            position: absolute;
            width: 80px;
            height: 80px;
            border-radius: 50%;
            background-color: rgba(93, 164, 226, 0.7); /* Soft blue bubble color */
            animation: floatAnimation 4s ease-in-out infinite;
        }

        @keyframes floatAnimation {
            0% {
                transform: translate(0, 0);
            }
            50% {
                transform: translate(150px, -200px);
            }
            100% {
                transform: translate(0, 0);
            }
        }

        .floating1 {
            top: 10%;
            left: 10%;
            animation-delay: 0s;
        }

        .floating2 {
            top: 50%;
            left: 60%;
            animation-delay: 1s;
        }

        .floating3 {
            top: 80%;
            left: 30%;
            animation-delay: 2s;
        }

        .floating4 {
            top: 15%;
            left: 80%;
            animation-delay: 3s;
        }
</style>
</head>

<body>
<div class="container" id="container">
    <form>
            <table border="0" class="table" cellpadding="5" cellspacing="5">
                <tr>
                    <th colspan=6>
                        <h3 class='SubHead'><u>Book Management :</u></h3>
                    </th>
                </tr>
                <tr>
                    <td><a href="addBooks.php" class="Command">Add Books</a></td>
                    <td><a href="bookRequests.php" class="Command">Desired Books</a></td>
                </tr>
                <tr>
                    <td><a href="slcbook.php" class="Command">Modify Books</a></td>
                    <td><a href="Delete.php" class="Command">Delete Books</a></td>
                </tr>
            </table>
            <table border="0" class="table" cellpadding="5" cellspacing="5">
                <tr>
                    <th colspan=6>
                        <h3 class='SubHead'><u>Request Management :</u></h3>
                    </th>
                </tr>
                <td><a href="demandes.php" class="Command">Loan Requests</a></td>
                <td><a href="pret.php" class="Command"> Loan Management </a></td>
                </tr>
            </table>
            <table border="0" class="table" cellpadding="5" cellspacing="5">
                <tr>
                    <th colspan=6>
                        <h3 class='SubHead'><u>Profile :</u></h3>
                    </th>
                </tr>
                <tr>
                    <td><a href="logout.php" class="Command">Log Out</a></td>
                    <td><a href="changePasswordAdmin.php" class="Command">Change Password</a></td>
                </tr>
            </table>
    </form>
        </div>

<div>
            <a class="a" href="admin.php" class="link">Back</a>
</div>
</body>
<!-- Floating interactive bubbles -->
<div class="floating floating1"></div>
    <div class="floating floating2"></div>
    <div class="floating floating3"></div>
    <div class="floating floating4"></div>
</html>
