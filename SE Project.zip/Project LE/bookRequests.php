<?php
include("setting.php");
session_start();
if(!isset($_SESSION['aid'])) {
    header("location:index.php");
}
$aid = $_SESSION['aid'];
$a = mysqli_query($set, "SELECT * FROM admin WHERE aid='$aid'");
$b = mysqli_fetch_array($a);
$name = $b['name'];
$bn = $_POST['name'];
$au = $_POST['auth'];

if($bn != NULL && $au != NULL) {
    $sql = mysqli_query($set, "INSERT INTO books(name, author) VALUES('$bn', '$au')");
    if($sql) {
        $msg = "Ajouté avec succès";
    } else {
        $msg = "Le livre existe déjà";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Livres souhaités</title>
    <link rel="shortcut icon" href="pic/logo.png" type="image/png">
    <style>
        @import url('https://fonts.googleapis.com/css?family=Montserrat:400,800');

        * {
            box-sizing: border-box;
        }

        body {
            background: #f6f5f7;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            font-family: 'Montserrat', sans-serif;
            height: 100vh;
            margin: -20px 0 50px;
        }

        a {
            color: #333;
            font-size: 14px;
            text-decoration: none;
            margin: 15px 0;
        }

        button {
            border-radius: 20px;
            border: 1px solid #fff;
            background-color: #fff;
            color: #fff;
            font-size: 12px;
            font-weight: bold;
            padding: 12px 45px;
            letter-spacing: 1px;
            text-transform: uppercase;
            transition: transform 80ms ease-in;
        }

        .container {
            background-color: #352322;
            border-radius: 10px;
            box-shadow: 0 14px 28px rgba(0, 0, 0, 0.25), 0 10px 10px rgba(0, 0, 0, 0.22);
            position: relative;
            overflow: hidden;
            width: 700px;
            max-width: 80%;
            min-height: 500px;
            margin: 8px 0;
        }

        form {
            background: linear-gradient(45deg, #1e3c72, #2a5298);
            background-size: 100% 100%;
            animation: gradientAnimation 8s ease infinite;
            display: flex;
            align-items: left;
            justify-content: center;
            flex-direction: column;
            padding: 0 50px;
            height: 100%;
            text-align: left;
        }

        @keyframes gradientAnimation {
            0% {
                background-position: 0% 50%;
            }
            50% {
                background-position: 100% 50%;
            }
            100% {
                background-position: 0% 50%;
            }
        }

        .labels, td {
            font-family: 'Segoe UI', sans-serif;
            color: #f6f5f7;
            font-size: 18px;
            margin-top: 20px;
        }

        .fields {
            width: calc(100% - 16px);
            padding: 3px;
            border-radius: 5px;
            box-sizing: border-box;
        }

        u, a {
            color: #fff;
        }

        .a {
            color: #4c372f;
        }

        .floating {
            position: absolute;
            width: 80px;
            height: 80px;
            border-radius: 50%;
            background-color: rgba(93, 164, 226, 0.7);
            animation: floatAnimation 4s ease-in-out infinite;
        }

        @keyframes floatAnimation {
            0% {
                transform: translate(0, 0);
            }
            50% {
                transform: translate(150px, -200px);
            }
            100% {
                transform: translate(0, 0);
            }
        }

        .floating1 {
            top: 10%;
            left: 10%;
            animation-delay: 0s;
        }

        .floating2 {
            top: 50%;
            left: 60%;
            animation-delay: 1s;
        }

        .floating3 {
            top: 80%;
            left: 30%;
            animation-delay: 2s;
        }

        .floating4 {
            top: 15%;
            left: 80%;
            animation-delay: 3s;
        }

    </style>
</head>

<body>

    <span class="SubHead">Desired books</span>

    <div class="container" id="container">
        <form>
            <table border="0" class="table" cellpadding="10" cellspacing="10">
                <tr class="labels" style="text-decoration:underline;">
                    <th>Nom du livre</th>
                    <th>Auteur</th>
                    <th>Demandé par<br>(ID Etudiant)</th>
                </tr>
                <?php
                $x = mysqli_query($set, "SELECT * FROM request");
                while($y = mysqli_fetch_array($x)) {
                ?>
                <tr class="labels" style="font-size:14px;">
                    <td><?php echo $y['name']; ?></td>
                    <td><?php echo $y['author']; ?></td>
                    <td><?php echo $y['sid']; ?></td>
                </tr>
                <?php
                }
                ?>
            </table>
        </form>
    </div>

    <div>
        <a class="a" href="adminhome.php" class="link">Back</a>
    </div>
</body>

<div class="floating floating1"></div>
<div class="floating floating2"></div>
<div class="floating floating3"></div>
<div class="floating floating4"></div>

</html>
