-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 12, 2025 at 06:08 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `library`
--

-- --------------------------------------------------------

--
-- Table structure for table `accepter`
--

CREATE TABLE `accepter` (
  `id_A` int(20) NOT NULL,
  `utilisateur` varchar(30) NOT NULL,
  `sid` varchar(30) NOT NULL,
  `isbn` int(30) NOT NULL,
  `name` varchar(255) NOT NULL,
  `author` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `rendu` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `accepter`
--

INSERT INTO `accepter` (`id_A`, `utilisateur`, `sid`, `isbn`, `name`, `author`, `date`, `rendu`) VALUES
(0, 'H130106921', 'AYYADI Imane', 0, 'Soft skills for the Workspace', 'Goodheart-Willcox ', '2025-01-12', '2025-01-28');

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `aid` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`aid`, `name`, `password`) VALUES
('admin', 'Admin', '21232f297a57a5a743894a0e4a801fc3');

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `isbn` int(100) NOT NULL,
  `name` varchar(255) NOT NULL,
  `author` varchar(255) NOT NULL,
  `genre` varchar(255) NOT NULL,
  `qte` int(30) NOT NULL,
  `image` varchar(255) NOT NULL,
  `id` double NOT NULL,
  `Description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`isbn`, `name`, `author`, `genre`, `qte`, `image`, `id`, `Description`) VALUES
(0, 'R for data science', 'Hadley Wickham', '', 14, 'Data.jpg', 36975, 'Data Science integrates statistics, computer science, and domain knowledge to extract insights from data, with R programming serving as a key tool for data preprocessing, analysis, visualization, and machine learning.');

-- --------------------------------------------------------

--
-- Table structure for table `issue`
--

CREATE TABLE `issue` (
  `id` int(255) NOT NULL,
  `utilisateur` varchar(30) NOT NULL,
  `sid` varchar(255) NOT NULL,
  `isbn` float NOT NULL,
  `name` varchar(255) NOT NULL,
  `author` varchar(255) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp(),
  `rendu` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `issue`
--

INSERT INTO `issue` (`id`, `utilisateur`, `sid`, `isbn`, `name`, `author`, `date`, `rendu`) VALUES
(1111139, 'H130106921', 'AYYADI Imane', 197531, 'countdown to zero day\n', 'Claude Delannoy', '2025-01-21 07:58:36', '2025-01-31');

-- --------------------------------------------------------

--
-- Table structure for table `request`
--

CREATE TABLE `request` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `author` varchar(255) NOT NULL,
  `sid` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `request`
--

INSERT INTO `request` (`id`, `name`, `author`, `sid`) VALUES
(9, 'Statistic', 'David Freedman', 'F12131417'),
(12, 'statistics', 'David Freedman', 'F12131417'),
(14, 'Statistics Done', 'Alex Reinhart', 'F12131417'),
(17, 'Statistics and Data Analyst', 'Alex Reinhart', 'H130106921'),
(18, 'KTAB', 'LABAIR ', 'F12131415');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(255) NOT NULL,
  `sid` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `branch` varchar(255) NOT NULL,
  `sem` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `sid`, `name`, `branch`, `sem`, `password`, `email`) VALUES
(1111133, '51245', 'Hilmi Rajaa', 'IGOV', 's1', '827ccb0eea8a706c4c34a16891f84e7b', 'rajaahilmi6@gmail.com'),
(1111134, 'F12131415', 'ELJABLI Saad', 'IGOV', 's1', '72429611eba4c13e6dce86c7f27fcb15', 'saad-eljabli@um5.ac.ma'),
(1111136, 'F12131416', 'OUTIRSTE Mouad', 'IGOV', 's1', 'de345b20a5d60ae93088b864977ea7cb', 'outirstemouad@um5.ac.ma'),
(1111138, 'F12131417', 'Bassir Houssein', 'IGOV', 's1', 'c5b2cebf15b205503560c4e8e6d1ea78', 'housseinbassir@um5.ac.ma'),
(1111140, 'G10111213', 'EL MAATAOUI Hamid', 'IGOV', 's1', '08f90c1a417155361a5c4b8d297e0d78', 'hamidelmaataoui@um5.ac.ma'),
(1111141, 'H12131415', 'GASMI Aya', 'IESE', 's1', 'd9bcad1eca7b1bb63bbfdf3289ef4737', 'gasmiaya@um5.ac.ma'),
(1111143, 'test', 'trst', '2I2S', 's1', '098f6bcd4621d373cade4e832627b4f6', 'test@gmail.com'),
(1111144, 'H130106921', 'AYYADI Imane', '2I2S', 's1', 'fc0688767206b473d7518ad9211c35cb', 'ayyadiimane@um5.ac.ma');

-- --------------------------------------------------------

--
-- Table structure for table `suspend`
--

CREATE TABLE `suspend` (
  `ids` int(20) NOT NULL,
  `sID` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `name` int(30) NOT NULL,
  `field` int(30) NOT NULL,
  `semester` int(30) NOT NULL,
  `email` int(30) NOT NULL,
  `password` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `suspend`
--

INSERT INTO `suspend` (`ids`, `sID`, `name`, `field`, `semester`, `email`, `password`) VALUES
(0, '1111139', 0, 0, 0, 0, 0),
(0, '1111139', 0, 0, 0, 0, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`aid`);

--
-- Indexes for table `issue`
--
ALTER TABLE `issue`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `request`
--
ALTER TABLE `request`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `sid` (`sid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `issue`
--
ALTER TABLE `issue`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1111145;

--
-- AUTO_INCREMENT for table `request`
--
ALTER TABLE `request`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1111145;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
