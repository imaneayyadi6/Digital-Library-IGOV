<?php
include("setting.php");
session_start();
if(!isset($_SESSION['sid']))
{
	header("location:index.php");
}
$sid=$_SESSION['sid'];
$a=mysqli_query($set,"SELECT * FROM students WHERE sid='$sid'");
$b=mysqli_fetch_array($a);
$name=$b['name'];
?>
<!DOCTYPE html PUBLIC">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Digital Library</title>
<link rel="chortcut icon" href="um5.png" type="images/png">

<link rel="chortcut icon" href="kb/pic/logo.png" type="images/png">


</head>
<style>@import url('https://fonts.googleapis.com/css?family=Montserrat:400,800');

* {
    box-sizing: border-box;
}

body {
    background: #f6f5f7;
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
    font-family: 'Montserrat', sans-serif;
    height: 100vh;
    margin: -20px 0 50px;
}


a {
    color: #333;
    font-size: 14px;
    text-decoration: none;
    margin: 15px 0;
}

button {
    border-radius: 20px;
    border: 1px solid #fff;
    background-color: #fff;
    color:  #fff;
    font-size: 12px;
    font-weight: bold;
    padding: 12px 45px;
    letter-spacing: 1px;
    text-transform: uppercase;
    transition: transform 80ms ease-in;
}

.container {
background-color: #352322;
border-radius: 10px;
box-shadow: 0 14px 28px rgba(0, 0, 0, 0.25), 0 10px 10px rgba(0, 0, 0, 0.22);
position: relative;
overflow: hidden;
width: 700px;
max-width: 80%;
min-height: 500px; 
margin: 8px 0; 
}


@keyframes show {
    0%, 49.99% {
        opacity: 0;
        z-index: 1;
    }
    
    50%, 100% {
        opacity: 1;
        z-index: 5;
    }
}

form {
    background: linear-gradient(45deg, #1e3c72, #2a5298);
    background-size: 200% 200%;
    animation: gradientAnimation 8s ease infinite;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;
    padding: 0 50px;
    height: 100%;
    text-align: center;
}

@keyframes gradientAnimation {
    0% {
        background-position: 0% 50%;
    }
    50% {
        background-position: 100% 50%;
    }
    100% {
        background-position: 0% 50%;
    }
}
span {
    color:#fff ;
}
th {
    color:#fff ;
}
a {
    color:#fff ;
}
/* Floating bubbles */
.floating {
    position: absolute;
    width: 60px;
    height: 60px;
    border-radius: 50%;
    background-color: rgba(59, 141, 189, 0.6); /* Soft blue bubble color */
    animation: floatAnimation 4s ease-in-out infinite;
}

@keyframes floatAnimation {
    0% {
        transform: translate(0, 0);
    }
    50% {
        transform: translate(100px, -150px);
    }
    100% {
        transform: translate(0, 0);
    }
}

.floating1 { top: 10%; left: 10%; animation-delay: 0s; }
.floating2 { top: 50%; left: 60%; animation-delay: 1s; }
.floating3 { top: 80%; left: 20%; animation-delay: 2s; }
.floating4 { top: 25%; left: 80%; animation-delay: 3s; }

</style>
<body>
<div class="container" id="container">

<form>
<span >Hello <?php echo $name;?></span>
<br />
<br />
<table border="0" class="table" cellpadding="10" cellspacing="10" width=500px>
<th colspan=10 class="SubHead">Option </th>
<tr><td><a href="kb/empr.php" class="Command">Borrow a Book</a></td>
<td><a href="request.php" class="Command">Request New Books</a></td></tr>
</table>
<br />
<br />
<table border="0" class="table" cellpadding="10" cellspacing="10" width=500px>
<th colspan=10 class="SubHead">PROFIL </th>
<tr><td><a href="changePassword.php" class="Command">Modify Password</a></td><td><a href="logout.php" class="Command">Log Out</a></td></tr>
</table>
</form>
</div>
<div>
            <a href="kb/empr.php" class="link">Retour</a>
</div>
</body>
<!-- Floating bubbles -->
<div class="floating floating1"></div>
<div class="floating floating2"></div>
<div class="floating floating3"></div>
<div class="floating floating4"></div>
</html>