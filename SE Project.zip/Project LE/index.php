<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IGOV Library</title>
    <link rel="chortcut icon" href="um5.png" type="images/png">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Dela+Gothic+One&family=Poppins:wght@100;200;400;500&display=swap');

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        html {
            font-size: 62.5%;
        }

        body {
            margin: 0;
            overflow-x: hidden;
            background: linear-gradient(45deg, #1e3c72, #2a5298);
            background-size: 400% 400%;
            animation: gradientMove 15s ease infinite;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        @keyframes gradientMove {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }

        .container {
            flex-grow: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
            color: #fff;
        }

        section {
            position: absolute;
            top: 20px;
            right: 6%;
            z-index: 2;
        }

        .menu {
            background-color: #fff;
            height: 60px;
            width: 60px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .menu:hover {
            background-color: #ecf0f1;
        }

        .menu::before,
        .menu::after {
            position: absolute;
            content: "";
            height: 4px;
            width: 20px;
            background-color: #3498db;
            border-radius: 6px;
            transition: transform 0.3s ease;
        }

        .menu::after {
            transform: translateY(8px);
        }

        .menu.active::before {
            transform: translateY(-8px) rotate(-45deg);
        }

        .menu.active::after {
            transform: translateY(0) rotate(45deg);
        }

        .content {
            z-index: 1;
        }

        .logo {
            padding-top: 2px;
        }

        .logo h2 {
            font-family: 'Dela Gothic One', sans-serif;
            font-size: 40px;
            font-weight: 100;
            color: #fff;
            letter-spacing: 5px;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.2);
        }

        .content hr {
            border: 0;
            height: 6px;
            max-width: 280px;
            margin-top: 8px;
            background-color: #fff;
            border-radius: 6px;
        }

        .content h1 {
            font-size: 60px;
            font-weight: 400;
            line-height: 80px;
            color: #fff;
            animation: fadeInUp 1.5s ease-out;
        }

        .content p {
            max-width: 300px;
            margin: 20px auto;
            line-height: 20px;
            font-size: 15px;
            animation: fadeIn 1.5s ease-out;
        }

        .content .btn {
            font-size: 12px;
            text-decoration: none;
            border: 2px solid #fff;
            color: #3498db;
            padding: 20px 40px;
            display: inline-block;
            margin-top: 60px;
            margin-right: 40px;
            border-radius: 30px;
            transition: background-color 0.3s ease, color 0.3s ease;
        }

        .content .btn:hover {
            background-color: #3498db;
            border: 2px solid #3498db;
            color: #1e3c72;
        }

        .lg {
            width: 160px;
            height: 160px;
            margin-right: 20px;
        }

        nav {
            position: fixed;
            top: 25px;
            left: 0;
            width: 100%;
            padding: 10px 0;
            z-index: 3;
        }

        nav ul {
            display: flex;
            justify-content: center;
            list-style: none;
        }

        nav li {
            margin: 0 15px;
        }

        nav a {
            text-decoration: none;
            color: #fff;
            font-weight: bold;
            font-size: 18px;
        }

        /* Floating bubbles animation */
        .floating {
            position: absolute;
            width: 80px;
            height: 80px;
            border-radius: 50%;
            background-color: rgba(93, 164, 226, 0.7); /* Soft blue bubble color */
            animation: floatAnimation 4s ease-in-out infinite;
        }

        @keyframes floatAnimation {
            0% {
                transform: translate(0, 0);
            }
            50% {
                transform: translate(150px, -200px);
            }
            100% {
                transform: translate(0, 0);
            }
        }

        .floating1 {
            top: 10%;
            left: 10%;
            animation-delay: 0s;
        }

        .floating2 {
            top: 50%;
            left: 60%;
            animation-delay: 1s;
        }

        .floating3 {
            top: 80%;
            left: 30%;
            animation-delay: 2s;
        }

        .floating4 {
            top: 15%;
            left: 80%;
            animation-delay: 3s;
        }

        footer {
            background-color: linear-gradient(45deg, #1e3c72, #2a5298);
            color: white;
            padding: 15px 0;
            margin-top: 0;
            position: relative;
            overflow: hidden;
        }

        .container-footer {
            display: flex;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 20px;
        }

        .departement, .liens-utiles, .contact {
            flex: 1;
        }
        footer {
            text-align: center;
            padding: 20px 0;
            background-color: rgba(30, 58, 138, 0.8); /* Matching footer with content box */
            margin-bottom: 10px;
        }
        .foot {
            font-size: 10px;
            line-height: 1.5;
            margin-bottom: 10px;
            color: #E0F2FE; /* Light blue for footer text */
        }
    </style>
</head>
<body>
    
<div class="container">
    <nav>
        <ul>
            <li><a href="homee.php">Home</a></li>
            <li><a href="about.php">About</a></li>
            <li><a href="services.php">Services</a></li>
        </ul>
    </nav>
    <div class="content">
        <a href="http://igov.edu.ma" target="_blank">
            <br><br><br><br><br><br><br><br><br><br><br><br>

        </a>
        <div class="logo">
            <h2>IGOV Digital Library</h2>
        </div>
        <hr>
        <h1>Welcome to the Digital Library</h1>
        <hr>
        <a href="Connexion.php" class="btn">Student Login</a>
        <a href="admin.php" class="btn">Admin Login</a>
    </div>
</div>

<footer style="background-color: linear-gradient(45deg, #1e3c72, #2a5298); color: white; padding: 15px 0; position: relative; overflow: hidden; margin-top: 0;">
  <div class="container" style="display: flex; justify-content: space-between; flex-wrap: wrap; gap: 20px;">
    <!-- Computer Science Department - IGOV -->
    <div class="department" style="flex: 1;">
      <h4 style="text-transform: uppercase;">Department of Computer Science - IGOV</h4>
      <hr style="width: 50px; background-color: #007bff; height: 2px; border: none;">
      <p>
        Discover the programs and projects of the Computer Science department, specialized in IGOV.
      </p>
    </div>

    <!-- Useful Links -->
    <div class="useful-links" style="flex: 1;">
      <h4 style="text-transform: uppercase;">Useful Links</h4>
      <hr style="width: 50px; background-color: #007bff; height: 2px; border: none;">
      <ul style="list-style-type: none; padding: 0; margin: 0;">
        <li><a href="https://www.um5.ac.ma/um5/" style="text-decoration: none; color: #007bff;">University Med V of Rabat</a></li>
        <li><a href="https://www.enssup.gov.ma/fr" style="text-decoration: none; color: #007bff;">Ministry of National Education</a></li>
        <li><a href="http://www.fsr.ac.ma/content/informatique-gouvernance-et-transformation-digitale" style="text-decoration: none; color: #007bff;">IGOV Documentation</a></li>
      </ul>
    </div>

    <!-- Contact -->
    <div class="contact" style="flex: 1;">
      <h4 style="text-transform: uppercase;">Contact</h4>
      <hr style="width: 50px; background-color: #007bff; height: 2px; border: none;">
      <p>Email: <a href="mailto:info@igov.edu.ma" style="text-decoration: none; color: #007bff;">info@igov.edu.ma</a></p>
      <p>Phone: +212 5 22 234 567</p>
    </div>
  </div>
  <br>
  <div><p class="foot">&copy; 2024 Digital Library IGOV. All rights reserved.</p></div>

</footer>

<!-- Floating interactive bubbles -->
<div class="floating floating1"></div>
    <div class="floating floating2"></div>
    <div class="floating floating3"></div>
    <div class="floating floating4"></div>
</body>

</html>
