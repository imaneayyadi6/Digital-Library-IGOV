<?php
include("../setting.php");
session_start();
if(!isset($_SESSION['sid']))
{
	header("location:index.php");
}
$sid=$_SESSION['sid'];
$a=mysqli_query($set,"SELECT * FROM students WHERE sid='$sid'");
$b=mysqli_fetch_array($a);
$name=$b['name'];
?>

<!DOCTYPE html>
<html lang="fr">
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Books">
    <title>Digital Library</title>
    <link rel="chortcut icon" href="um5.png" type="images/png">

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="chortcut icon" href="C:\xampp\htdocs\rapp\kb\pic\logo.png" type="images/png">

    <style>
   
    #books {margin-bottom:50px;}

        @media only screen and (width: 767px) { body{margin-top:150px;}}
        #books .row{margin-top:20px;margin-bottom:10px;font-weight:800;}
        @media only screen and (max-width: 760px) { #books .row{margin-top:10px;}}

    /********************header*************************/
      .modal-header {background:#9a372f;color:#fff;font-weight:800;}
      .modal-body{font-weight:800;}
      .modal-body ul{list-style:none;}
      .modal .btn {background:#001F3F;color:#fff;}
      .modal a{color:#001F3F;}
      .modal-backdrop {position:inherit !important;}
       #login_button,#register_button{background:none;color:#D67B22!important;}       
       #query_button {position:fixed;right:0px;bottom:0px;padding:10px 80px;
                      background-color:#9a372f;color:#fff;border-radius:2px;}
  	  @media(max-width:767px){
        #query_button {padding: 5px 20px;}
  	  }
      .navbar a.logo {
      float: left;
      padding: 0px 2px;
     }
/********************body*************************/

      body {margin-top:50px;margin-left:5%;margin-right:5%;font-family:"Open sans";background: #fff;overflow-x:hidden;}
        .navbar {background:#3b8dbd;display:inline-block;z-index:100;color:#000;}
        .navbar li a {color:#fff!important;}
        #top {border:1px solid #fff;background:#fff;border-radius:10px;}
        #searchbox {background:#fff;overflow:hidden;}
        #header{margin-top:20px;}
        #myCarousel {border:1px solid #ccc;margin-top:10px;}
        #myCarousel img {width:100%;}
        #category ul{list-style-type:none;overflow:hidden;width:100%; border:1px solid #ccc;background: #fff; border-bottom-right-radius:10px;border-bottom-left-radius: 10px;}
        #category li {display:block; font-weight:400; padding:10px; border-top: 1px solid #ccc;margin-left:-40px; }
        #offer img {margin-top:10px;margin-bottom:15px;border:1px solid #DEEAEE;}
        #new {font-weight:800;}
        .tag {display:inline;float:left;padding:2px 5px;width:auto;background:#90e137;color:#fff;height:23px;}
        .tag-side{display:inline;float:left;}
        .book-block {margin-top:20px;padding:5px;background:#fff; border :1px solid #DEEAEE;border-radius:10px;}
        #author {margin-top:20px; background:#fff; border :1px solid #DEEAEE;border-radius:10px;}
        #author .row {margin-top: 20px; margin-bottom:20px;}
        #author h3{color:rgb(228, 55, 25);}
        .label-warning ,span{
            background:#9a372f;
        }
        .back-button {
  position: fixed;
  bottom: 20px; /* Adjust the distance from the bottom */
  left: 50%;
  transform: translateX(-50%);
  background-color: #2a5298;
  color: white;
  padding: 10px 20px;
  border-radius: 5px;
  text-align: center;
  text-decoration: none;
  font-size: 16px;
}
    </style>

</head>
<body>

    <nav class="navbar navbar-default navbar-fixed-top navbar-inverse">
      <div class="container-fluid">
        
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
        </div>

        
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
          <ul class="nav navbar-nav navbar-right">
              <?php
                  if(isset($_SESSION['sid']))
                    {
                      echo'
					<li> <a href="../request.php" class="btn btn-lg"> Book Desired </a> </li>
                    <li> <a href="../changePassword.php" class="btn btn-lg"> Modify Password </a> </li>
                    <li> <a href="../logout.php" class="btn btn-lg"> Log Out </a> </li>
                         ';
                    }
               ?>
          </ul>
        </div>
      </div>
    </nav>

    <div id="top" >
        <div id="searchbox" class="container-fluid" style="width:112%;margin-left:-6%;margin-right:-6%;">
            <div>
                <form role="search" action="Result.php" method="post">
                    <input type="text" name="keyword" class="form-control" placeholder=" Book , type, field" style="width:80%;margin:20px 10% 20px 10%;">
                </form>
            </div>
        </div>

    <?php
    include "dbconnect.php";
    if(isset($_GET['value']))
        {  
           $_SESSION['category']=$_GET['value'];
        }
    $category=$_SESSION['category'];
    if(isset($_POST['sort']))
    {
        if($_POST['sort']=="price")
                {   $query = "SELECT * FROM books WHERE genre='$category' ";
				
                    $result = mysqli_query ($con,$query)or die(mysqli_error($con));
                    ?>
                       <script type="text/javascript">
                          document.getElementById('select').Selected=$_POST['sort'];
                       </script>
                    <?php
                }
        else
        if($_POST['sort']=="priceh")
                {   $query = "SELECT * FROM books WHERE genre='$category' ";
						
                    $result = mysqli_query ($con,$query)or die(mysqli_error($con));
                }
        else
        if($_POST['sort']=="discount")
                {   $query = "SELECT * FROM books WHERE genre='$category'";
							
                    $result = mysqli_query ($con,$query)or die(mysqli_error($con));
                }
        else
        if($_POST['sort']=="discountl")
                {   $query = "SELECT * FROM books WHERE genre='$category'";
				
                    $result = mysqli_query ($con,$query)or die(mysqli_error($con));
                }
    } 
    else   
            {   $query = "SELECT * FROM books WHERE genre='$category'";
			
                $result = mysqli_query ($con,$query)or die(mysqli_error($con));
            } 
    $i=0;
    echo '<div class="container-fluid" id="books">
        <div class="row">
          <div class="col-xs-12 text-center" id="heading">
                 <h2 style="color:#001F3Fs;text-transform:uppercase;margin-bottom:0px;"> '. $category .'  </h2>
           </div>
        </div>      
        <div class="container fluid">
             <div class="row">
                  <div class="col-sm-5 col-sm-offset-6 col-md-5 col-md-offset-7 col-lg-4 col-lg-offset-8">
                       
                       
                  </div>
              </div>
        </div>';

        if(mysqli_num_rows($result) > 0) 
        {   
            while($row = mysqli_fetch_assoc($result)) 
            {
            $path="../pic/" .$row['image']."";
            $description="description.php?ID=".$row["id"];
            if($i%4==0)
            echo '<div class="row">';
            echo'
               <a href="'.$description.'">
                <div class="col-sm-6 col-md-3 col-lg-3 text-center">
                    <div class="book-block" style="border :3px solid #DEEAEE;">
                        <img class="book block-center img-responsive" src="'.$path.'">
                        <hr>
                         ' . $row["name"] . '<br>
                        ' . $row["author"] .'  &nbsp
                        
                        <span class="label label-warning">'. $row["qte"] .' disponibles</span>
                    </div>
                </div>
                
               </a> ';
            $i++;
            if($i%4==0)
            echo '</div>';
            }
        }
    echo '</div>';
    ?>


<a href="empr.php" class="link back-button">Back</a>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
   
    <script src="js/bootstrap.min.js"></script>
</body>
</html>	
