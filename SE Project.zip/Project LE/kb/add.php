<?php
include("../setting.php");
session_start();

if (!isset($_SESSION['sid'])) {
    header("location:index.php");
    exit();
}

$sid = $_SESSION['sid'];
$a = mysqli_query($set, "SELECT * FROM students WHERE sid='$sid'");
$b = mysqli_fetch_array($a);
$name = $b['name'];
$sid = $b['sid'];

$ID = $_GET['ID'];
$ds = $_POST['ds'];  // Make sure this is sanitized

$query = "SELECT * FROM books WHERE id='$ID'";  // Fixing the query for safer use
$result = mysqli_query($set, $query) or die(mysqli_error($set));
$row = mysqli_fetch_assoc($result);

$rendu = mysqli_real_escape_string($set, $ds);  // Sanitize input for SQL
$i = $row["id"];
$n = $row["name"];
$a = $row["author"];

// Check if the book is found
if ($row) {
    $query_insert = "INSERT INTO `issue`(`sid`, `name`, `isbn`, `author`, `rendu`, `utilisateur`) 
                     VALUES ('$name', '$n', '$i', '$a', '$rendu', '$sid')";

    // Check for query execution
    if (mysqli_query($set, $query_insert)) {
        header("location:Product.php");
        exit();
    } else {
        echo "Error: " . mysqli_error($set);
    }
} else {
    echo "Book not found!";
}
?>
