<?php
include("setting.php");
session_start();
if(isset($_SESSION['aid']))
{
	
}
$aid=mysqli_real_escape_string($set,$_POST['aid']);
$pass=mysqli_real_escape_string($set,$_POST['pass']);

if($aid==NULL || $_POST['pass']==NULL)
{
	//
}
else
{
	$p=md5($pass);
	$sql=mysqli_query($set,"SELECT * FROM admin WHERE aid='$aid' AND password='$p'");
	if(mysqli_num_rows($sql)==1)
	{
		$_SESSION['aid']=$_POST['aid'];
		header("location:adminhome.php");
	}
	else
	{
		$msg="Les coordonnés saisis sont incorrects";
	}
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Digital Library</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            overflow: hidden;
            background: #102333;
            color: #fff;
            background-image: url(images/a.jpeg); 
            background-size: cover;
        }

        header {
            background: linear-gradient(to right, #253747, #99A4AD);
            padding: 20px;
            text-align: left;
            color: #fff;
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-direction: row;
            animation: fadeIn 1.5s ease-out, slideIn 1.5s ease-out;
        }

        .head {
            font-size: 24px;
        }

        @keyframes fadeIn {
            0% {
                opacity: 0;
            }
            100% {
                opacity: 1;
            }
        }

        .clg {
            color: #253747;
            font-weight: bold;
            font-size: 14px;
            position: absolute;
            white-space: nowrap;
            animation: moveInPage 9s linear infinite;
        }

        @keyframes moveInPage {
            0% {
                left: -100%;
            }
            100% {
                left: 100%;
            }
        }

        #wrapper {
            background-color: #99A4AD;
            border-radius: 8px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            padding: 10px;
            width: 70%;
            margin: 20px auto;
            animation: zoomIn 1s ease-out;
        }

        .SubHead {
            font-size: 14px;
            font-weight: bold;
            color: #001F3F;
            margin-top: 10px;
        }

        .table {
            width: 100%;
        }

        .labels {
            font-weight: bold;
            padding-bottom: 5px;
            color: #001F3F;
        }

        .fields {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
            border: 1px solid #001F3F;
            border-radius: 4px;
            box-sizing: border-box;
        }

        .msg {
            color: #001F3F;
        }

        .link {
            color: #001F3F;
            text-decoration: none;
            font-weight: bold;
            display: inline-block;
            padding: 8px;
            background-color: #fff;
            border-radius: 4px;
            transition: background-color 0.3s ease-out;
        }

        .link:hover {
            background-color: #001F3F;
            color: #fff;
        }
    </style>
</head>

<body>
    <header>
        <div class="text">
            <span class="head">Bibliothèque ESEF-O</span>
        </div>
    </header>

    <marquee class="clg" direction="right" behavior="alternate" scrollamount="1">Bienvenue dans la Bibliothèque Numérique de l'Ecole Supérieure de l'Éducation et de la Formation</marquee>

    <div align="center">
        <div id="wrapper">
            <br />
            <br />

            <span class="SubHead">Identification Admin</span>
            <br />
            <br />
            <form method="post" action="">
                <table border="0" cellpadding="4" cellspacing="4" class="table">
                    <tr>
                        <td colspan="2" align="center" class="msg"><?php echo $msg;?></td>
                    </tr>
                    <tr>
                        <td class="labels">Nom d'utilisateur: </td>
                        <td><input type="text" name="aid" class="fields" size="25" placeholder="Entrer le nom d'utilisateur"
                                required="required" /></td>
                    </tr>
                    <tr>
                        <td class="labels">Mot de passe : </td>
                        <td><input type="password" name="pass" class="fields" size="25" placeholder="Entrer mot de passe "
                                required="required" /></td>
                    </tr>
                    <tr>
                        <td colspan="2" align="center"><input type="submit" value="Identification" class="fields" /></td>
                    </tr>
                </table>
            </form>
            <br />
            <br />
            <a href="index.php" class="link">Page d'Accueil</a>
            <br />
            <br />
        </div>
    </div>
</body>

</html>
