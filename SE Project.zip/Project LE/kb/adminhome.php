


<?php
include("setting.php");
session_start();
if(!isset($_SESSION['aid'])) {
    header("location:index.php");
}
$aid = $_SESSION['aid'];
$a = mysqli_query($set, "SELECT * FROM admin WHERE aid='$aid'");
$b = mysqli_fetch_array($a);
$name = $b['name'];
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Digital Library</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #F4F4F9;
        }

        header {
            background: linear-gradient(to right, #6a9cfc, #b0d6ff);
            padding: 15px 25px;
            text-align: center;
            color: #fff;
            font-size: 24px;
            font-weight: bold;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .marquee {
            color: #6a9cfc;
            font-weight: bold;
            font-size: 14px;
            padding: 10px;
            text-align: center;
        }

        #wrapper {
            background-color: #ffffff;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            width: 85%;
            margin: 30px auto;
            padding: 20px;
            animation: zoomIn 1s ease-out;
        }

        .SubHead {
            font-size: 18px;
            font-weight: bold;
            color: #3b4d63;
            margin-top: 15px;
        }

        .table {
            width: 100%;
            border-radius: 10px;
            margin-top: 20px;
            text-align: center;
        }

        .Command {
            text-decoration: none;
            color: #ffffff;
            background-color: #6a9cfc;
            padding: 8px 15px;
            border-radius: 25px;
            margin: 5px;
            transition: all 0.3s;
        }

        .Command:hover {
            background-color: #4a83e5;
            box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.2);
        }

        @keyframes zoomIn {
            0% {
                transform: scale(0);
            }
            100% {
                transform: scale(1);
            }
        }

        footer {
            text-align: center;
            font-size: 12px;
            color: #6a9cfc;
            margin-top: 30px;
        }

        .button-container {
            text-align: center;
            margin-bottom: 20px;
        }

        .button-container a {
            text-decoration: none;
            color: #fff;
            background-color: #6a9cfc;
            padding: 10px 20px;
            border-radius: 25px;
            margin: 5px;
            font-size: 16px;
            transition: all 0.3s ease;
        }

        .button-container a:hover {
            background-color: #4a83e5;
            box-shadow: 0 0 8px rgba(0, 0, 0, 0.2);
        }
    </style>
</head>

<body>
    <header>Digital Library</header>
    <link rel="chortcut icon" href="um5.png" type="images/png">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Dela+Gothic+One&family=Poppins:wght@100;200;400;500&display=swap">

    <marquee class="marquee" direction="right" behavior="alternate" scrollamount="3">Bienvenue dans la Bibliothèque Numérique de l'Ecole Supérieure de l'Éducation et de la Formation</marquee>

    <div class="button-container">
        <a href="addBooks.php" class="Command">Ajouter des livres</a>
        <a href="bookRequests.php" class="Command">Livres souhaités</a>
        <a href="slcbook.php" class="Command">Modification des livres</a>
        <a href="supprimer.php" class="Command">Supprimer des livres</a>
        <a href="demandes.php" class="Command">Demandes d'emprunts</a>
        <a href="pret.php" class="Command">Gestion des prêts</a>
        <a href="logout.php" class="Command">Se déconnecter</a>
        <a href="changePasswordAdmin.php" class="Command">Modifier mot de passe</a>
    </div>

    <div id="wrapper">
        <span class="SubHead">Bienvenue <?php echo $name; ?></span>
        <table class="table">
            <tr>
                <th colspan="2">
                    <h3 class="SubHead"><u>Gestion des livres:</u></h3>
                </th>
            </tr>
            <tr>
                <td><a href="addBooks.php" class="Command">Ajouter des livres</a></td>
                <td><a href="bookRequests.php" class="Command">Livres souhaités</a></td>
            </tr>
            <tr>
                <td><a href="slcbook.php" class="Command">Modification des livres</a></td>
                <td><a href="supprimer.php" class="Command">Supprimer des livres</a></td>
            </tr>
        </table>

        <table class="table">
            <tr>
                <th colspan="2">
                    <h3 class="SubHead"><u>Gestion des demandes:</u></h3>
                </th>
            </tr>
            <tr>
                <td><a href="demandes.php" class="Command">Demandes d'emprunts</a></td>
                <td><a href="pret.php" class="Command">Gestion des prêts</a></td>
            </tr>
        </table>

        <table class="table">
            <tr>
                <th colspan="2">
                    <h3 class="SubHead"><u>Profil:</u></h3>
                </th>
            </tr>
            <tr>
                <td><a href="logout.php" class="Command">Se déconnecter</a></td>
                <td><a href="changePasswordAdmin.php" class="Command">Modifier mot de passe</a></td>
            </tr>
        </table>
    </div>

    <footer>
    &copy; 2024 Digital Library IGOV. All rights reserved.
    </footer>
</body>

</html>
