<?php
include("setting.php");
session_start();
if(!isset($_SESSION['aid']))
{
	header("location:index.php");
}
$aid=$_SESSION['aid'];
$a=mysqli_query($set,"SELECT * FROM admin WHERE aid='$aid'");
$b=mysqli_fetch_array($a);
$name=$b['name'];
$bn=$_POST['name'];
$au=$_POST['auth'];
if($bn!=NULL && $au!=NULL)
{
	$sql=mysqli_query($set,"INSERT INTO books(name,author) VALUES('$bn','$au')");
	if($sql)
	{
		$msg="Requested Successfully";
	}
	else
	{
		$msg="The Book already exist";
	}
}
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Livres souhaités</title>
<link rel="chortcut icon" href="pic/logo.png" type="images/png">
</head>

<style>
 body {
    font-family: 'Segoe UI', sans-serif;
    margin: 0;
    padding: 0;
    background: url(images/a.jpeg);
    background-size: cover;
}

header {
    background: linear-gradient(to right, #253747, #99A4AD);
    padding: 20px;
    color: #fff;
    text-align: left;
    animation: fadeIn 1.5s ease-out, slideIn 1.5s ease-out;
}

.head {
    font-size: 24px;
}

.clg {
    color: #001F3F;
    font-weight: bold;
    font-size: 14px;
    position: absolute;
    white-space: nowrap;
    animation: moveInPage 9s linear infinite;
}

#wrapper {
    background: #99A4AD;
    border-radius: 8px;
    box-shadow: 0 0 15px rgba(0, 0, 0, 0.2);
    padding: 20px;
    width: 70%;
    margin: 20px auto;
    animation: zoomIn 1s ease-out;
}

.SubHead {
    font-size: 16px;
    font-weight: bold;
    color: #001F3F;
    margin-top: 10px;
}

.table {
    width: 100%;
    border-radius: 5px;
    padding: 10px;
    border: 1px solid #001F3F;
	background-color: rgba(255, 255, 255, 0.7);
    margin-top: 10px;
}

.labels {
    font-weight: bold;
	color:#001F3F;
	text-align:center;
}

.link {
    text-decoration: none;
    color: #001F3F;
    font-size: 14px;
}

.link:hover {
    color: #001F3F;
}

@keyframes fadeIn {
    0% {
        opacity: 0;
    }
    100% {
        opacity: 1;
    }
}

@keyframes moveInPage {
    0% {
        left: -100%;
    }
    100% {
        left: 100%;
    }
}

@keyframes zoomIn {
    0% {
        transform: scale(0);
    }
    100% {
        transform: scale(1);
    }
}
</style>

<body>
<header>
    <div class="head">Bibliothèque ESEF-O</div>
</header>
<marquee class="clg" direction="right" behavior="alternate" scrollamount="1">Bienvenue dans la Bibliothèque Numérique de l'Ecole Supérieure de l'Éducation et de la Formation</marquee>
</div>
<br />

<div align="center">
    <div id="wrapper">
        <br />
        <br />

        <span class="SubHead">Livres souhaités </span>
        <br />
        <br />

        <table border="0" class="table" cellpadding="10" cellspacing="10">
            <tr class="labels" style="text-decoration:underline;">
                <th>Nom du livre</th>
                <th>Auteur</th>
                <th>Demandé par<br>(ID Etudiant) </th>
            </tr>
            <?php
            $x=mysqli_query($set,"SELECT * FROM request");
            while($y=mysqli_fetch_array($x))
            {
                ?>
                <tr class="labels" style="font-size:14px;">
                    <td><?php echo $y['name'];?></td>
                    <td><?php echo $y['author'];?></td>
                    <td><?php echo $y['sid'];?></td>
                </tr>
                <?php
            }
            ?>
        </table><br />
        <br />
        <a href="adminhome.php" class="link">Retour</a>
        <br />
        <br />

    </div>
</div>
</body>
</html>