<?php
include("setting.php");
session_start();
if(!isset($_SESSION['sid']))
{
	header("location:index.php");
}
$sid=$_SESSION['sid'];
$a=mysqli_query($set,"SELECT * FROM students WHERE sid='$sid'");
$b=mysqli_fetch_array($a);
$name=$b['name'];
$pass=$b['password'];
$old=md5($_POST['old']);
$p1=md5($_POST['p1']);
$p2=md5($_POST['p2']);
if($_POST['old']==NULL || $_POST['p1']==NULL || $_POST['p2']==NULL)
{
	
}
else
{
if($old!=$pass)
{
	$msg="Ancien mot de passe incorrect";
}
elseif($p1!=$p2)
	{
		$msg="Le nouveau mot de passe ne correspond pas";
	}
	else
	{
		mysqli_query($set,"UPDATE students SET password='$p2' WHERE sid='$sid'");
		$msg="Mot de passe changé avec succès";
	}

}

?>
<!DOCTYPE html >
<html >
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Changer le mot de  pass</title>
<link rel="chortcut icon" href="pic/logo.png" type="images/png">
</head>
<style>
        body {
            font-family: 'Segoe UI', sans-serif;
            margin: 0;
            padding: 0;
            background: url(images/a.jpeg);
            background-size: cover;
        }

        header {
            background: linear-gradient(45deg, #1e3c72, #2a5298);
            padding: 20px;
            color: #fff;
            text-align: left;
            animation: fadeIn 1.5s ease-out, slideIn 1.5s ease-out;
        }

        .head {
            font-size: 24px;
        }

        .clg {
            color: #001F3F;
            font-weight: bold;
            font-size: 14px;
            white-space: nowrap;
        }

        #wrapper {
            background: #99A4AD;
            border-radius: 8px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.2);
            padding: 20px;
            width: 70%;
            margin: 20px auto;
        }

        .SubHead {
            font-size: 16px;
            font-weight: bold;
            color: #001F3F;
            margin-top: 10px;
        }

        .table {
            width: 100%;
            border-radius: 5px;
            padding: 10px;
            border: 1px solid #001F3F;
            background-color: rgba(255, 255, 255, 0.8);
            margin-top: 10px;
        }

        .labels, .SubHead, .link {
            color: #001F3F;
            text-decoration: none;
        }
        
        .links {
            color: #042138;
        }
        
        .fields {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
            border: 1px solid #001F3F;
            border-radius: 4px;
            box-sizing: border-box;
        }

        .msg {
            color: #001F3F;
        }
    </style>
<body>
    <header>
        <div class="head">Bibliothèque ESEF-O</div>
    </header>
	<marquee class="clg" direction="right" behavior="alternate" scrollamount="1">Bienvenue dans la Bibliothèque Numérique de l'Ecole Supérieure de l'Éducation et de la Formation</marquee>
<br/>
<div align="center">
<div id="wrapper">
<br/><br/>
<span class="SubHead">Changer le mot de passe</span>
<br/><br/>
    <form method="post" action="">
       <table cellpadding="3" cellspacing="3" class="table" align="center">
            <tr><td colspan="2" class="msg" align="center"><?php echo $msg;?></td></tr>
            <tr><td class="labels">Ancien mot de passe :</td><td><input type="password" name="old" size="25" class="fields" placeholder="Entrer l'ancien mot de passe" required="required" /></td></tr>
            <tr><td class="labels">Nouveau mot de passe :</td><td><input type="password" name="p1" size="25" class="fields" placeholder="Enter un nouveau mot de passe" required="required"  /></td></tr>
            <tr><td class="labels">Re-entrer mot de passe :</td><td><input type="password" name="p2" size="25"  class="fields" placeholder="Re-entrer le nouveau mot de passe " required="required" /></td></tr>
            <tr><td colspan="2" align="center"><input type="submit" value="Changer mot de passe" class="fields" /></td></tr>
        </table>
    </form>
<br/><br/>
<a href="kb/empr.php" class="link">Retour</a>
<br/><br/>
</div>
</div>
</body>
</html>