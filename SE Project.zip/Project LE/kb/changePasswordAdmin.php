<?php
include("setting.php");
session_start();
if(!isset($_SESSION['aid']))
{
	header("location:index.php");
}
$aid=$_SESSION['aid'];
$a=mysqli_query($set,"SELECT * FROM admin WHERE aid='$aid'");
$b=mysqli_fetch_array($a);
$name=$b['name'];
$pass=$b['password'];
$old=md5($_POST['old']);
$p1=md5($_POST['p1']);
$p2=md5($_POST['p2']);
if($_POST['old']==NULL || $_POST['p1']==NULL || $_POST['p2']==NULL)
{
	
}
else
{
if($old!=$pass)
{
	$msg="Ancien mot de passe incorrect";
}
elseif($p1!=$p2)
	{
		$msg="Le nouveau mot de passe ne correspond pas";
	}
	else
	{
		mysqli_query($set,"UPDATE admin SET password='$p2' WHERE aid='$aid'");
		$msg="Successfully Changed your Password";
	}

}

?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Bibliothèque ESEF-O</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            margin: 0;
            padding: 0;
            background: url(images/a.jpeg);
            background-size: cover;
        }

        header {
            background: linear-gradient(to right, #253747, #99A4AD);
            padding: 20px;
            color: #fff;
            text-align: left;
            animation: fadeIn 1.5s ease-out, slideIn 1.5s ease-out;
        }

        .head {
            font-size: 24px;
        }


        .clg {
            color: #001F3F;
            font-weight: bold;
            font-size: 14px;
            white-space: nowrap;
        }

        #wrapper {
            background: #99A4AD;
            border-radius: 8px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.2);
            padding: 20px;
            width: 50%;
            margin: 20px auto;
        }

        .SubHead {
            font-size: 16px;
            font-weight: bold;
            color: #001F3F;
            margin-top: 10px;
        }

        .table {
            width: 100%;
            border-radius: 5px;
            padding: 15px;
            border: 1px solid #001F3F;
            background-color: rgba(255, 255, 255, 0.8);
            margin-top: 20px;
        }

        .labels, .fields,  {
            color: #001F3F;
            text-decoration: none;
        }
		.labels a{
			color:#001F3F;
			
		}
        .msg {
            color: #001F3F;
        }

       @keyframes fadeIn {
            0% {
                opacity: 0;
            }
            100% {
                opacity: 1;
            }
        }

        @keyframes moveInPage {
            0% {
                left: -100%;
            }
            100% {
                left: 100%;
            }
        }

        @keyframes zoomIn {
            0% {
                transform: scale(0);
            }
            100% {
                transform: scale(1);
            }
        }
    </style>
</head>

<body>
<header>
        <div class="head">Bibliothèque ESEF-O</div>
    </header>
	<marquee class="clg" direction="right" behavior="alternate" scrollamount="1">Bienvenue dans la Bibliothèque Numérique de l'Ecole Supérieure de l'Éducation et de la Formation</marquee>
</div>

    <div align="center">
        <div id="wrapper">
            <br />
            <br />

            <span class="SubHead">Changer le mot de passe</span>
            <br />
            <br />
            <form method="post" action="">
                <table cellpadding="10" cellspacing="10" class="table" align="center">
                    <tr><td colspan="2" class="msg" align="center"><?php echo $msg;?></td></tr>
                    <tr><td class="labels"><a>Ancien mot de passe :</a></td><td><input type="password" name="old" size="30" class="fields" placeholder="Entrer l'ancien mot de passe" required="required" /></td></tr>
                    <tr><td class="labels"><a>Nouveau mot de passe :</a></td><td><input type="password" name="p1" size="30" class="fields" placeholder="Entrer un nouveau mot de passe" required="required"  /></td></tr>
                    <tr><td class="labels"><a>Re-entrer le mot de passe :</a></td><td><input type="password" name="p2" size="30"  class="fields" placeholder="Re-entrer le mot de passe" required="required" /></td></tr>
                    <tr><td colspan="2" align="center"><input type="submit" value="Changer mot de passe" class="fields" style="background-color: #001F3F; color: #fff; cursor: pointer; border: none; padding: 10px 20px; border-radius: 5px; font-size: 16px;" /></td></tr>
                </table>
            </form>
            <br />
            <br />
            <a href="adminhome.php" class="link">Retour</a>
            <br />
            <br />
        </div>
    </div>
</body>
</html>

