<?php
include("../setting.php");
session_start();
if(!isset($_SESSION['sid'])) {
    header("location:index.php");
}

$sid = $_SESSION['sid'];
$a = mysqli_query($set, "SELECT * FROM students WHERE sid='$sid'");
$b = mysqli_fetch_array($a);
$name = $b['name'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
   <title>Digital Library</title>
   <link rel="chortcut icon" href="um5.png" type="images/png">
   <link href="css/bootstrap.min.css" rel="stylesheet">
   <link rel="chortcut icon" href="um5.png" type="images/png">
  <style>
/********************header*************************/
      .modal-header {background:#fff;;color:#fff;font-weight:800;}
      .modal-body{font-weight:800;}
      .modal-body ul{list-style:none;}
      .modal .btn {background:#3b8dbd;color:#fff;}
      .modal a{color:#D67B22;}
      .modal-backdrop {position:inherit !important;}
       #login_button,#register_button{background:none;color:#D67B22!important;}       
       #query_button {position:fixed;right:0px;bottom:0px;padding:10px 80px;
                      background-color:#3b8dbd;color:#fff;border-radius:2px;}
  	@media(max-width:767px){
        #query_button {padding: 5px 20px;}
  	}
      .navbar a.logo {
    float: left;
    padding: 0px 2px;
  }
/********************body*************************/

      body {margin-top:50px;margin-left:5%;margin-right:5%;font-family:"Open sans";background: #fff;overflow-x:hidden;}
        .navbar {background:#3b8dbd;display:inline-block;z-index:100;color:#000;}
        .navbar li a {color:#fff!important;}
        #top {border:1px solid #DEEAEE;background:#fff;border-radius:10px;}
        #searchbox {background:#fff;overflow:hidden;}
        /*****Images Scrolling******/
        #header{margin-top:20px;}
        #myCarousel {border:6px solid #ccc;margin-top:70px;left:25%}
        #myCarousel img {width:100%;}
        #category ul{list-style-type:none;overflow:hidden;width:100%; border:2px solid #ccc;background: #fff;}
        #category li {display:block; font-weight:400; padding:10px; border-top: 1px solid #ccc;margin-left:-40px; }
        #new {font-weight:800;}
        .tag {display:inline;float:left;padding:2px 5px;width:auto;background:#90e137;color:#fff;height:23px;}
        .tag-side{display:inline;float:left;}
        .book-block {margin-top:20px;padding:5px;background:#fff; border :1px solid #DEEAEE;border-radius:10px;}
        #author {margin-top:20px; background:#fff; border :1px solid #DEEAEE;border-radius:10px;}
        #author .row {margin-top: 20px; margin-bottom:20px;}
        #author h3{color:rgb(228, 55, 25);}
        
/********************footer*************************/
footer{
  height:auto;
  width:100%;
  font-family: "Open Sans";
  padding-top: 40px;
  color: #ececec;
  position: absolute;
  bottom: 100;
  left: 0;
  right: 0;
}
.footer-bottom{
  background: #3b8dbd;
  width: 100%;
  padding:20px 0;
  
  text-align:center;
}
.footer-bottom p{
  font-size: 14px;
  word-spacing: 2px;
  text-transform: capitalize;
}
.lg {
            width: 150px;
            height: 40px;
            margin-top: 5px;
            margin-right:700px;
        }


</style>
</head>
<body>
  <nav class="navbar navbar-default navbar-fixed-top navbar-inverse">
      <div class="container-fluid">
        
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
        </div>
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
         <ul class="nav navbar-nav navbar-right">
        <?php
        if(!isset($_SESSION['sid']))
          {
            echo'
            <li>
                <button type="button" id="login_button" class="btn btn-lg" data-toggle="modal" data-target="#login">Login</button>
                  <div id="login" class="modal fade" role="dialog">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                                <h4 class="modal-title text-center">Login Form</h4>
                            </div>
                            <div class="modal-body">
                                          <form class="form" role="form" method="post" action="index.php" accept-charset="UTF-8">
                                              <div class="form-group">
                                                  <label class="sr-only" for="username">Username</label>
                                                  <input type="text" name="login_username" class="form-control" placeholder="Username" required>
                                              </div>
                                              <div class="form-group">
                                                  <label class="sr-only" for="password">Password</label>
                                                  <input type="password" name="login_password" class="form-control"  placeholder="Password" required>
                                              </div>
                                              <div class="form-group">
                                                  <button type="submit" name="submit" value="login" class="btn btn-block">
                                                      Sign in
                                                  </button>
                                              </div>
                                          </form>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                            </div>
                        </div>
                    </div>
                  </div>
            </li>
            <li>
              <button type="button" id="register_button" class="btn btn-lg" data-toggle="modal" data-target="#register">Sign Up</button>
                <div id="register" class="modal fade" role="dialog">
                  <div class="modal-dialog">
                      <div class="modal-content">
                          <div class="modal-header">
                              <button type="button" class="close" data-dismiss="modal">&times;</button>
                              <h4 class="modal-title text-center">Member Registration Form</h4>
                          </div>
                          <div class="modal-body">
                                        <form class="form" role="form" method="post" action="index.php" accept-charset="UTF-8">
                                            <div class="form-group">
                                                <label class="sr-only" for="username">Username</label>
                                                <input type="text" name="register_username" class="form-control" placeholder="Username" required>
                                            </div>
                                            <div class="form-group">
                                                <label class="sr-only" for="password">Password</label>
                                                <input type="password" name="register_password" class="form-control"  placeholder="Password" required>
                                            </div>
                                            <div class="form-group">
                                                <button type="submit" name="submit" value="register" class="btn btn-block">
                                                    Sign Up
                                                </button>
                                            </div>
                                        </form>
                          </div>
                          <div class="modal-footer">
                              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                          </div>
                      </div>
                  </div>
                </div>
            </li>';
          } 
        else
          {   echo' 
           
                    <li><img class="lg" src="igov.png"></li>
                    <li> <a href="../profile.php" class="btn btn-lg"> Hello ' .$name. '.</a></li>
                    <li> <a href="../request.php" class="btn btn-lg"> Desired Book </a> </li>	  
                    <li> <a href="../changePassword.php" class="btn btn-lg"> Modify Password </a> </li>
                    <li> <a href="../logout.php" class="btn btn-lg"> Log Out </a> </li>';
					
               
          }
?>

          </ul>
        </div>
      </div>
    </nav>
  <div id="top" >
      <div id="searchbox" class="container-fluid" style="width:112%;margin-left:-6%;margin-right:-6%;">
          <div>
              <form role="search" method="POST" action="Result.php">
                  <input type="text" class="form-control" name="keyword" style="width:80%;margin:20px 10% 20px 10%;" placeholder="Search a book , field or category">
              </form>
          </div>
      </div>

      <div class="container-fluid" id="header">
          <div class="row">
              <div class="col-md-3 col-lg-3" id="category">
                  <div style="background:#3b8dbd;color:#fff;font-weight:800;border:none;padding:15px;"> Category </div>
                  <ul>
                      <li> <a href="Product.php?value=EXAMS"> EXAMS </a> </li>
                      <li> <a href="Product.php?value=Advanced Algorithms">Advanced Algorithms</a> </li>
                      <li> <a href="Product.php?value=Advanced Information Systems">Advanced Information Systems</a> </li>
                      <li> <a href="Product.php?value=Information Systems Security">Information Systems Security</a> </li>
                      <li> <a href="Product.php?value= Languages"> Languages</a> </li>
                      <li> <a href="Product.php?value=Mobile Architectures">Mobile Architectures</a> </li>
                      <li> <a href="Product.php?value=Soft Skills">Soft Skills</a> </li>
                      <li> <a href="Product.php?value=Software Engineering">Software Engineering</a> </li>
                      <li> <a href="Product.php?value=SQL/NoSQL Databases">SQL/NoSQL Databases</a> </li>
                      <li> <a href="Product.php?value=Statistics and Data Analysis">Statistics and Data Analysis</a> </li>



                  </ul>
              </div>
              <div class="col-md-6 col-lg-6">
                  <div id="myCarousel" class="carousel slide carousel-fade" data-ride="carousel">
                      <!-- Indicators -->
                      <ol class="carousel-indicators">
                          <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
                          <li data-target="#myCarousel" data-slide-to="1"></li>
                          <li data-target="#myCarousel" data-slide-to="2"></li>
                          <li data-target="#myCarousel" data-slide-to="3"></li>
                      </ol>
                      
                        
                          <div class="carousel-inner" role="listbox">
                          <div class="item active">
                            <img class="img-responsive" src="pic/pic1.png">
                          </div>
                          <div class="item">
                            <img class="img-responsive "src="pic/pic2.png">
                          </div>
                          <div class="item">
                            <img class="img-responsive" src="pic/picc3.png">
                          </div>
                          <div class="item">
                            <img class="img-responsive"src="pic\Biblio4.jpg">
                          </div>

                      </div>
                  </div>
              </div>
              
          </div>
      </div>
  </div>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <footer>
        <div class="footer-bottom">
          <p>&copy; 2024 Digital Library IGOV. All rights reserved.</p>
        </div>
</footer>
    <div class="container">

  <button type="button" id="query_button" class="btn btn-lg" data-toggle="modal" data-target="#query">CONTACT  US!</button>
 
  <div class="modal fade" id="query" role="dialog">
    <div class="modal-dialog">
      <div class="modal-content">
          <div class="modal-header text-center">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title">Ask  a question here </h4>
          </div>
          <div class="modal-body">           
                    <form method="post" action="query.php" class="form" role="form">
                        <div class="form-group">
                             <label class="sr-only" for="name">Name</label>
                             <input type="text" class="form-control"  placeholder="Enter Your name" name="sender" required>
                        </div>
                        <div class="form-group">
                             <label class="sr-only" for="email">Email</label>
                             <input type="email" class="form-control" placeholder="abc@mail.com" name="senderEmail" required>
                        </div>
                        <div class="form-group">
                             <label class="sr-only" for="query">Message</label>
                             <textarea class="form-control" rows="5" cols="30" name="message" placeholder="Enter Your Message" required></textarea>
                        </div>
                        <div class="form-group">
                              <button type="submit" name="submit" value="query" class="btn btn-block">
                                                              Send
                               </button>
                        </div>
                    </form>
          </div>
          <div class="modal-footer">
              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
          </div>
      </div>
    </div>  
  </div>
</div>  
</body>
</html>	