<?php
include("setting.php");
session_start();
if(!isset($_SESSION['sid'])) {
    header("location:index.php");
}
$sid = $_SESSION['sid'];
$a = mysqli_query($set, "SELECT * FROM students WHERE sid='$sid'");
$b = mysqli_fetch_array($a);
$name = $b['name'];
?>
<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Digital Library</title>
    <link rel="shortcut icon" href="um5.png" type="images/png">
    <style>
        @import url('https://fonts.googleapis.com/css?family=Montserrat:400,800');

        * {
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', sans-serif;
            margin: 0;
            padding: 0;
            background: url(images/a.jpeg);
            background-size: cover;
        }

        header {
            background: linear-gradient(to right, #253747, #99A4AD);
            padding: 20px;
            color: #fff;
            text-align: left;
        }

        .head {
            font-size: 24px;
        }

        .clg {
            color: #001F3F;
            font-weight: bold;
            font-size: 14px;
            white-space: nowrap;
        }

        .container {
            background-color: rgba(255, 255, 255, 0.8);
            border-radius: 8px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.2);
            position: relative;
            width: 700px;
            max-width: 80%;
            min-height: 500px;
            padding: 20px;
            text-align: center;
            margin: 30px auto;
        }

        .SubHead {
            font-size: 16px;
            font-weight: bold;
            color: #001F3F;
            margin-top: 10px;
        }

        .table {
            width: 100%;
            border-radius: 5px;
            padding: 10px;
            border: 1px solid #001F3F;
            background-color: rgba(255, 255, 255, 0.8);
            margin-top: 10px;
        }

        .labels, .link {
            font-family: 'Segoe UI', sans-serif;
            color: #001F3F;
            font-size: 18px;
            margin-top: 20px;
            text-decoration: none;
        }

        .fields {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
            border: 1px solid #001F3F;
            border-radius: 4px;
            box-sizing: border-box;
        }

        .msg {
            color: #001F3F;
            text-align: center;
        }

        .link {
            margin-top: 20px;
            display: inline-block;
            font-size: 14px;
            color: #001F3F;
            text-decoration: none;
        }

        /* Floating bubbles */
        .floating {
            position: absolute;
            width: 60px;
            height: 60px;
            border-radius: 50%;
            background-color: rgba(59, 141, 189, 0.6);
            animation: floatAnimation 4s ease-in-out infinite;
        }

        @keyframes floatAnimation {
            0% { transform: translate(0, 0); }
            50% { transform: translate(100px, -150px); }
            100% { transform: translate(0, 0); }
        }

        .floating1 { top: 10%; left: 10%; animation-delay: 0s; }
        .floating2 { top: 50%; left: 60%; animation-delay: 1s; }
        .floating3 { top: 80%; left: 20%; animation-delay: 2s; }
        .floating4 { top: 25%; left: 80%; animation-delay: 3s; }
    </style>
</head>
<body>

<div class="container">
    <header>
        <div class="head">Bibliothèque ESEF-O</div>
    </header>

    <marquee class="clg" direction="right" behavior="alternate" scrollamount="1">Bienvenue dans la Bibliothèque Numérique de l'Ecole Supérieure de l'Éducation et de la Formation</marquee>

    <span class="SubHead">Book Request</span>
    <form method="post" action="">
        <table border="0" class="table" cellpadding="10" cellspacing="10">
            <tr><td class="msg" align="center" colspan="2"><?php echo $msg;?></td></tr>
            <tr><td class="labels">Book: </td><td><input type="text" size="25" class="fields" required="required" name="name" placeholder="Enter the book's name" /></td></tr>
            <tr><td class="labels">Author: </td><td><input type="text" size="25" class="fields" required="required" name="author" placeholder="Enter author's name" /></td></tr>
            <tr><td colspan="2" align="center"><input type="submit" class="fields" value="Request" /></td></tr>
        </table>
    </form>

    <div><a href="kb/empr.php" class="link">Back</a></div>
</div>

<!-- Floating bubbles -->
<div class="floating floating1"></div>
<div class="floating floating2"></div>
<div class="floating floating3"></div>
<div class="floating floating4"></div>

</body>
</html>
