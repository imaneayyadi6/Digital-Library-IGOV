<?php
include("setting.php");
session_start();
if(!isset($_SESSION['sid']))
{
	
}
$sid=$_SESSION['sid'];
$a=mysqli_query($set,"SELECT * FROM issue WHERE sid='$sid'");
$b=mysqli_fetch_array($a);
$name=$b['name'];
$date=date('d/m/Y');
$bn=$_POST['name'];
if($bn!=NULL)
{
	$p=mysqli_query($set,"SELECT * FROM books WHERE id='$bn'");
	$q=mysqli_fetch_array($p);
	$bk=$q['name'];
	$ba=$q['author'];
	$sql=mysqli_query($set,"INSERT INTO issue(sid,name,author,date) VALUES('$sid','$bk','$ba','$date')");
	if($sql)
	{
		$msg="Added Successfully";
	}
	else
	{
		$msg="error";
	}
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Gestion de pret</title>
    <link rel="chortcut icon" href="pic/logo.png" type="images/png">

    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            margin: 0;
            padding: 0;
            background: url(images/a.jpeg);
            background-size: cover;
        }

        
        header {
            background: linear-gradient(to right, #253747, #99A4AD);
            padding: 20px;
            color: #fff;
            text-align: left;
            animation: fadeIn 1.5s ease-out, slideIn 1.5s ease-out;
        }

        .head {
            font-size: 24px;
        }

        .clg {
            color: #001F3F;
            font-weight: bold;
            font-size: 14px;
            white-space: nowrap;
        }

        #wrapper {
            background: #99A4AD;
            border-radius: 8px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.2);
            padding: 20px;
            width: 70%;
            margin: 20px auto;
        }

        .SubHead {
            font-size: 16px;
            font-weight: bold;
            color: #001F3F;
            margin-top: 10px;
        }
		
        .table {
            width: 100%;
            border-radius: 5px;
            padding: 10px;
            border: 1px solid #001F3F;
            background-color: rgba(255, 255, 255, 0.8);
            margin-top: 10px;
        }

        .labels, .SubHead {
            color: #001F3F;
            text-decoration: none;
        }
		.links {
			color:#042138;
		}
		link{
			color:#fff;
		}
		a.link:hover{font-family:"Segoe UI";font-size:16px;color:#F6F;text-decoration:none;}

        .msg {
            color: #001F3F;
        }
    </style>
</head>

<body>
<header>
        <div class="head">Bibliothèque ESEF-O</div>
    </header>
	<marquee class="clg" direction="right" behavior="alternate" scrollamount="1">Bienvenue dans la Bibliothèque Numérique de l'Ecole Supérieure de l'Éducation et de la Formation</marquee>
</div>
    <br />

    <div align="center">
        <div id="wrapper">
            <br />
            <br />

            <span class="SubHead">Gestion des prêts </span>
            <br />
            <br />

            <table border="0" class="table" cellpadding="10" cellspacing="10">
                <tr><td colspan="7" align="center" class="msg"><?php echo $msg;?></td></tr>
                <tr>
                    <td class='labels'>Étudiant</td>
                    <td class='labels'>Date d'emprunt</td>
                    <td class='labels'>Date de retour</td>
                    <td class='labels'>Livre</td>
                    <td class='labels'>Rendu</td>
                    <td class='labels'>Suspendre</td>
                    <td class='labels'>Contacter</td>
                </tr>

                <?php
                $x=mysqli_query($set,"SELECT * FROM accepter");
                while($y=mysqli_fetch_assoc($x))
                {
                ?>
                <tr>
                    <td class='SubHead'><?php echo $y['sid'];?></td>
                    <td class='SubHead'><?php echo $y['date'];?></td>
                    <td class='SubHead'><?php echo $y['rendu'];?></td>
                    <td class='SubHead'><?php echo $y['name']." ".$y['author'];?></td>
                    <td><a class='links' href="rendu.php?var=<?php echo($y['date']) ?>"><b>Rendu</b></a></td>
                    <td><a class='links' href="susp.php?var=<?php echo($y['utilisateur']) ?>"><b>Suspendre</b></a></td>
                    <td><a class='labels' href="https://mail.google.com/mail/u/0/?fs=1&tf=cm"><b>Contactez</b></a></td>
                </tr>
                <?php
                }
                ?>
            </table>

            <br />
            <br />
            <a href="adminhome.php" class="link">Retour</a>
            <br />
            <br />

        </div>
    </div>
</body>
</html>
