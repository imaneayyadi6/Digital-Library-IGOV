<?php
include("setting.php");

function getUserInfo($sid) {
    global $set;
    $a = mysqli_query($set, "SELECT * FROM students WHERE sid='$sid'");
    return mysqli_fetch_array($a);
}

session_start();
if (!isset($_SESSION['sid'])) {
    header("location:index.php");
}
$sid = $_SESSION['sid'];
$userInfo = getUserInfo($sid);
$name = $userInfo['name'];
$email = $userInfo['email'];
$sem = $userInfo['sem'];
$branch = $userInfo['branch'];
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Student's Profile</title>
   <link rel="chortcut icon" href="um5.png" type="images/png">

    <style>
    body {
            font-family: 'Segoe UI', sans-serif;
            margin: 0;
            padding: 0;
            background: url(images/a.jpeg);
            background-size: cover;
        }

        header {
            font-family: 'Segoe UI', sans-serif;
            background: linear-gradient(to right, #253747, #99A4AD);
            padding: 20px;
            color: #fff;
            text-align: left;
            animation: fadeIn 1.5s ease-out, slideIn 1.5s ease-out;
        }

        .head {
            font-size: 24px;
        }

        .clg {
            font-family: 'Segoe UI', sans-serif;
            color: #001F3F;
            font-weight: bold;
            font-size: 14px;
            white-space: nowrap;
        }

        #wrapper {
            background: #99A4AD;
            border-radius: 8px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.2);
            padding: 20px;
            width: 70%;
            margin: 20px auto;
        }

        .SubHead {
            font-family: 'Segoe UI', sans-serif;
            font-size: 16px;
            font-weight: bold;
            color: #001F3F;
            margin-top: 10px;
        }

        .table {
            width: 100%;
            border-radius: 5px;
            padding: 10px;
            border: 1px solid #001F3F;
            background-color: rgba(255, 255, 255, 0.8);
            margin-top: 10px;
        }

        .labels, .SubHead, .link  {
            font-family: 'Segoe UI', sans-serif;
            color: #001F3F;
            text-decoration: none;
        }
        
        .fields {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
            border: 1px solid #001F3F;
            border-radius: 4px;
            box-sizing: border-box;
        }

        .msg {
            color: #001F3F;
            text-align: center;
        }
    </style>
    
</head>

<body>
    <header>
        <div class="head">Bibliothèque ESEF-O</div>
    </header>
	<marquee class="clg" direction="right" behavior="alternate" scrollamount="1">Bienvenue dans la Bibliothèque Numérique de l'Ecole Supérieure de l'Éducation et de la Formation</marquee>

    <div align="center">
        <div id="wrapper">
        <br/><br/>
        <span class="SubHead">Profile</span>
        <br/><br/>
   <form>
            <table border="0" cellpadding="4" cellspacing="4" class="table">
                <tr>
                    <td class="labels">Name : </td>
                    <td><?php echo $name; ?></td>
                </tr>
                <tr>
                    <td class="labels">Email ID : </td>
                    <td><?php echo $email; ?></td>
                </tr>
                <tr>
                    <td class="labels">Semester : </td>
                    <td><?php echo $sem; ?></td>
                </tr>
                <tr>
                    <td class="labels">Field of Study : </td>
                    <td><?php echo $branch; ?></td>
                </tr>
                <tr>
                    <td class="labels">ID student: </td>
                    <td><?php echo $sid; ?></td>
                </tr>
            </table>
    </form>
        <br/><br/>
            <a href="index.php" class="link">Back</a>
        <br/><br/>
        </div>
    </div>
</body>

</html>
