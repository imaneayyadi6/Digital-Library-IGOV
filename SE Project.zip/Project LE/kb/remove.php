<?php
include("setting.php");
session_start();

if (isset($_GET['var'])) {
    // Get the book ID from the URL parameter
    $book_id = $_GET['var'];

    // Check if the ID is valid
    if (!empty($book_id) && is_numeric($book_id)) {
        // Prepare the delete query to remove the book from the database
        $delete_query = "DELETE FROM books WHERE id = '$book_id'";

        // Execute the query
        $result = mysqli_query($set, $delete_query);

        if ($result) {
            // Book deleted successfully
            echo "Book deleted successfully!";
        } else {
            // Error occurred while deleting
            echo "Error deleting the book.";
        }
    } else {
        // Invalid book ID
        echo "Invalid book ID.";
    }
} else {
    // No book ID was provided
    echo "No book selected for deletion.";
}

// Redirect back to the book list page (optional)
header("Location: booklist.php"); // Modify to your actual book list page
exit;
?>
