<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Update Book Information</title>
<link rel="icon" href="um5.png" type="image/png">
<style>
* {
    box-sizing: border-box;
    font-family: 'Montserrat', sans-serif;
    margin: 0;
    padding: 0;
}

body {
    background-color: #e6f7ff; /* Soft light blue background */
    font-family: 'Montserrat', sans-serif;
    height: 100vh;
    margin: 0;
    display: flex;
    justify-content: center;
    align-items: center;
}

header {
    background-color: #3b8dbd; /* Soft blue header */
    color: #ffffff;
    text-align: center;
    padding: 10px;
    font-size: 24px;
    font-weight: bold;
    text-transform: uppercase;
    border-radius: 5px;
    width: 100%;
    max-width: 800px;
    margin-bottom: 20px;
}

.container {
    background-color: #ffffff; /* White background for the form */
    border-radius: 10px;
    box-shadow: 0 14px 28px rgba(0, 0, 0, 0.1), 0 10px 10px rgba(0, 0, 0, 0.1);
    width: 100%;
    max-width: 700px;
    margin-top: 10px;
    padding: 30px;
}

form {
    display: flex;
    flex-direction: column;
    gap: 10px;
}

.labels {
    font-size: 16px;
    font-weight: bold;
    color: #3b8dbd; /* Soft blue for labels */
}

.fields {
    padding: 10px;
    border-radius: 5px;
    border: 1px solid #b3d9ff; /* Light blue border */
    font-size: 16px;
    width: 100%;
}

input[type="file"] {
    padding: 10px;
}

textarea {
    padding: 10px;
    border-radius: 5px;
    border: 1px solid #b3d9ff; /* Light blue border */
    font-size: 16px;
    width: 100%;
    resize: vertical;
}

input[type="submit"] {
    background-color: #3b8dbd; /* Soft blue button */
    color: #ffffff;
    font-weight: bold;
    border: none;
    padding: 12px;
    border-radius: 5px;
    cursor: pointer;
    transition: background-color 0.3s ease;
}

input[type="submit"]:hover {
    background-color: #276fa1; /* Darker blue on hover */
}

.msg {
    text-align: center;
    color: #ff4d4d; /* Red for error messages */
    font-size: 18px;
}

.link {
    text-align: center;
    color: #3b8dbd;
    font-size: 16px;
    text-decoration: none;
    display: block;
    margin-top: 20px;
}

footer {
    background-color: #3b8dbd;
    color: #ffffff;
    text-align: center;
    padding: 10px;
    font-size: 14px;
    position: fixed;
    bottom: 0;
    width: 100%;
}

/* Floating bubbles */
.floating {
    position: absolute;
    width: 60px;
    height: 60px;
    border-radius: 50%;
    background-color: rgba(59, 141, 189, 0.6); /* Soft blue bubble color */
    animation: floatAnimation 4s ease-in-out infinite;
}

@keyframes floatAnimation {
    0% {
        transform: translate(0, 0);
    }
    50% {
        transform: translate(100px, -150px);
    }
    100% {
        transform: translate(0, 0);
    }
}

.floating1 { top: 10%; left: 10%; animation-delay: 0s; }
.floating2 { top: 50%; left: 60%; animation-delay: 1s; }
.floating3 { top: 80%; left: 20%; animation-delay: 2s; }
.floating4 { top: 25%; left: 80%; animation-delay: 3s; }

</style>
</head>
<body>
<header>Update Book Information</header>
<div class="container">
    <form method="post" action="" enctype="multipart/form-data">
        <div>
            <label class="labels">Book ISBN:</label>
            <input type="number" name="id" placeholder="Enter book ISBN" class="fields" required />
        </div>

        <div>
            <label class="labels">Book Name:</label>
            <input type="text" name="name" placeholder="Enter book name" class="fields" required />
        </div>

        <div>
            <label class="labels">Author:</label>
            <input type="text" name="auth" placeholder="Author" class="fields" required />
        </div>

        <div>
            <label class="labels">Quantity:</label>
            <input type="text" name="qte" placeholder="Quantity" class="fields" required />
        </div>
        <div>
            <label class="labels">Genre:</label>
            <select name="genre" class="fields">
                <option value="Advanced Algorithms">Advanced Algorithms</option>
                <option value="Advanced Information Systems">Advanced Information Systems</option>
                <option value="EXAMEN">Examen</option>
                <option value="Foreign Languages">Foreign Languages</option>
                <option value="Information Systems Security">Information Systems Security</option>
                <option value="Mobile Architectures">Mobile Architectures</option>
                <option value="Soft Skills">Soft Skills</option>
                <option value="Software Engineering">Software Engineering</option>
                <option value="SQL/NoSQL Databases">SQL/NoSQL Databases</option>
                <option value="Statistics and Data Analysis">Statistics and Data Analysis</option>
            </select>
        </div>
        <div>
            <label class="labels">Image:</label>
            <input type="file" name="photo" class="fields" required />
        </div>
        <div>
            <label class="labels">Description:</label>
            <textarea name="desc" rows="5" class="fields" placeholder="Description or summary..."></textarea>
        </div>
        <div style="text-align: center;">
            <input type="submit" value="Update Book" />
        </div>
        <div style="text-align: center; margin-top: 10px;">
        <a href="adminhome.php" class="link">Back</a>
        </div>
    </form>
</div>

<!-- Floating bubbles -->
<div class="floating floating1"></div>
<div class="floating floating2"></div>
<div class="floating floating3"></div>
<div class="floating floating4"></div>
</body>
</html>
