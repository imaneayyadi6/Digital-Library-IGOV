<?php
include("setting.php");
session_start();
if(!isset($_SESSION['sid']))
{
	
}
$sid=$_SESSION['sid'];
$a=mysqli_query($set,"SELECT * FROM students WHERE sid='$sid'");
$b=mysqli_fetch_array($a);
$name=$b['name'];
$date=date('d/m/Y');
$bn=$_POST['name'];
if($bn!=NULL)
{
	$p=mysqli_query($set,"SELECT * FROM books WHERE id='$bn'");
	$q=mysqli_fetch_array($p);
	$bk=$q['name'];
	$ba=$q['author'];
	$sql=mysqli_query($set,"INSERT INTO issue(sid,name,author,date) VALUES('$sid','$bk','$ba','$date')");
	if($sql)
	{
		$msg="Added";
	}
	else
	{
		$msg="ERROR";
	}
}
?>

<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Remove A Book</title>
<link rel="chortcut icon" href="um5.png" type="images/png">    </head>
</head>
<style>@import url('https://fonts.googleapis.com/css?family=Montserrat:400,800');

* {
    box-sizing: border-box;
}

body {
    background: #f6f5f7;
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
    font-family: 'Montserrat', sans-serif;
    height: 100vh;
    margin: -20px 0 50px;
    
}


a {
    color: #333;
    font-size: 14px;
    text-decoration: none;
    margin: 15px 0;
}

button {
    border-radius: 20px;
    border: 1px solid #fff;
    background-color: #fff;
    color:  #fff;
    font-size: 12px;
    font-weight: bold;
    padding: 12px 45px;
    letter-spacing: 1px;
    text-transform: uppercase;
    transition: transform 80ms ease-in;
}

.container {
background-color: #352322;
border-radius: 10px;
box-shadow: 0 14px 28px rgba(0, 0, 0, 0.25), 0 10px 10px rgba(0, 0, 0, 0.22);
position: relative;
overflow: hidden;
width: 700px;
max-width: 80%;
min-height: 500px; 
margin: 8px 0; 
}

@keyframes show {
    0%, 49.99% {
        opacity: 0;
        z-index: 1;
    }
    
    50%, 100% {
        opacity: 1;
        z-index: 5;
    }
}

form {
    background: linear-gradient(45deg, #1e3c72, #2a5298);
    background-size: 200% 200%;
    animation: gradientAnimation 8s ease infinite;
    display: flex;
    align-items: left;
    justify-content: center;
    flex-direction: column;
    padding: 0 50px;
    height: 100%;
    text-align: left;
    border-radius:5px;

}

@keyframes gradientAnimation {
    0% {
        background-position: 0% 50%;
    }
    
    100% {
        background-position: 0% 50%;
    }
}
.labels ,td{
            font-family: 'Segoe UI', sans-serif;
            color: #f6f5f7;
           font-size: 18px;margin-top: 20px;  
        }
        .fields {
            width: calc(100% - 16px);
            padding: 3px;
			border-radius:5px;
            box-sizing: border-box;
        }
        .floating {
            position: absolute;
            width: 80px;
            height: 80px;
            border-radius: 50%;
            background-color: rgba(93, 164, 226, 0.7); /* Soft blue bubble color */
            animation: floatAnimation 4s ease-in-out infinite;
        }

        @keyframes floatAnimation {
            0% {
                transform: translate(0, 0);
            }
            50% {
                transform: translate(150px, -200px);
            }
            100% {
                transform: translate(0, 0);
            }
        }

        .floating1 {
            top: 10%;
            left: 10%;
            animation-delay: 0s;
        }

        .floating2 {
            top: 50%;
            left: 60%;
            animation-delay: 1s;
        }

        .floating3 {
            top: 80%;
            left: 30%;
            animation-delay: 2s;
        }

        .floating4 {
            top: 15%;
            left: 80%;
            animation-delay: 3s;
        }

</style>
<body>
<br/><br/>
<br/><br/>
<br/><br/>
<br/><br/>
    <form>
        <table border="0" class="table" cellpadding="10" cellspacing="10">
            <tr><td colspan="2" align="center" class="msg"><?php echo $msg;?></td></tr>

            <?php
            $x=mysqli_query($set,"SELECT * FROM books");
            while($y=mysqli_fetch_assoc($x))
            {
            ?>
            <tr class="SubHead" >
                <td class='SubHead'> <?php echo $y['id'];?> </td>
                <td class='SubHead'><?php echo $y['name']." ".$y['author'];?></td>
                <td><img width=80px height=90px src="./pic/<?php echo $y['image']; ?>"></td>
                <th><a class='link' href="suppbook.php?var=<?php echo($y['id']) ?>">delete</a> </th>
            </tr>
            <?php
            }
            ?>
        </table>
        </form>

        <a href="adminhome.php" class="link">Back</a>
        <br />
        <br />
        <div class="floating floating1"></div>
    <div class="floating floating2"></div>
    <div class="floating floating3"></div>
    <div class="floating floating4"></div>  
</body>
</html>
