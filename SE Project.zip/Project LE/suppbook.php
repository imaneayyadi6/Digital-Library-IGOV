<?php
include("setting.php");
session_start();

// Check if the book ID is passed via URL
if(isset($_GET['var'])) {
    $book_id = $_GET['var'];
    
    // Query to delete the book from the database
    $delete_query = mysqli_query($set, "DELETE FROM books WHERE id = '$book_id'");

    // Check if the deletion was successful
    if ($delete_query) {
        $msg = "Book deleted successfully.";
    } else {
        $msg = "Error deleting the book.";
    }

    // Redirect back to the list page after deletion
    header("Location: your_page.php"); // Replace 'your_page.php' with the page where you display the list of books
    exit();
}
?>
